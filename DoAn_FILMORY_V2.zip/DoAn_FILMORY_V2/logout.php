<?php
require_once __DIR__ . '/config/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !auth_csrf_valid()) {
    http_response_code(403);
    exit('Yêu cầu không hợp lệ.');
}
unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);
session_regenerate_id(true);
header('Location: index.php');
exit;
