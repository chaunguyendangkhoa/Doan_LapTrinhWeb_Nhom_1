
<?php
require_once __DIR__ . "/config/auth.php";
require_once __DIR__ . "/config/database.php";
// Yeu cau dang nhap truoc khi dat hang.
if (!auth_logged_in()) {
    header('Location: login.php');
    exit;
}
$checkoutUserId = (int)$_SESSION['user_id'];

// Ham chong XSS
function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

// Ham dinh dang tien
function money($price) {
    return number_format(
        (float)$price, 0, ",", "."
    ) . "đ";
}

// Tinh so ngay thue
function rentalDays($startDate, $endDate) {
    if (!is_string($startDate) || !is_string($endDate)) {
        return 0;
    }

    $start = DateTimeImmutable::createFromFormat(
        "!Y-m-d", $startDate
    );
    $end = DateTimeImmutable::createFromFormat(
        "!Y-m-d", $endDate
    );

    if (
        !$start || !$end ||
        $start->format("Y-m-d") !== $startDate ||
        $end->format("Y-m-d") !== $endDate ||
        $end <= $start
    ) {
        return 0;
    }

    return (int)$start->diff($end)->days;
}

if (empty($_SESSION["checkout_csrf"])) {
    $_SESSION["checkout_csrf"] = bin2hex(random_bytes(32));
}

// Kiem tra gio hang
if (empty($_SESSION["cart"])) {
    header("Location: cart.php");
    exit;
}

$items = [];
$total = 0;
$error = "";
$success = false;
$orderId = null;

$name = trim($_POST["customer_name"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$address = trim($_POST["address"] ?? "");

// Lay san pham tu MySQL va tinh lai gia
foreach ($_SESSION["cart"] as $cartItem) {
    if (
        !is_array($cartItem) ||
        !isset($cartItem["product_id"], $cartItem["quantity"])
    ) {
        $error = "Dữ liệu giỏ hàng không hợp lệ!";
        break;
    }

    $id = (int)$cartItem["product_id"];
    $quantity = (int)$cartItem["quantity"];

    if ($id <= 0 || $quantity <= 0) {
        $error = "Số lượng sản phẩm không hợp lệ!";
        break;
    }

    $stmt = $conn->prepare(
        "SELECT id, name, price, product_type, stock
         FROM sanpham
         WHERE id = ?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) {
        $error = "Có sản phẩm không còn tồn tại!";
        break;
    }

    if ($quantity > (int)$product["stock"]) {
        $error = "Sản phẩm " . $product["name"] .
                 " không đủ số lượng tồn kho!";
        break;
    }

    $startDate = null;
    $endDate = null;
    $days = 1;

    if ($product["product_type"] === "thue") {
        $startDate = $cartItem["start_date"] ?? null;
        $endDate = $cartItem["end_date"] ?? null;

        $days = rentalDays($startDate, $endDate);

        if (
            $days < 1 ||
            $startDate < date("Y-m-d")
        ) {
            $error = "Ngày thuê của sản phẩm " .
                     $product["name"] . " không hợp lệ!";
            break;
        }
    } elseif ($product["product_type"] !== "mua") {
        $error = "Loại sản phẩm không hợp lệ!";
        break;
    }

    $price = (float)$product["price"];
    $subtotal = $price * $quantity * $days;
    $total += $subtotal;

    $items[] = [
        "product_id" => $id,
        "name" => $product["name"],
        "product_type" => $product["product_type"],
        "quantity" => $quantity,
        "price" => $price,
        "days" => $days,
        "start_date" => $startDate,
        "end_date" => $endDate,
        "subtotal" => $subtotal
    ];
}

// Xu ly dat hang
if (
    $_SERVER["REQUEST_METHOD"] === "POST" &&
    $error === ""
) {
    if (!hash_equals($_SESSION["checkout_csrf"], (string)($_POST["csrf_token"] ?? ""))) {
        $error = "Phiên đặt hàng không hợp lệ. Vui lòng tải lại trang.";
    } elseif ($name === "" || $phone === "" || $address === "") {
        $error = "Vui lòng nhập đầy đủ thông tin!";
    } elseif (
        mb_strlen($name) > 100 ||
        mb_strlen($address) > 255 ||
        !preg_match('/^0[0-9]{9,10}$/', $phone)
    ) {
        $error = "Thông tin khách hàng không hợp lệ!";
    } else {
        try {
            // Bat dau transaction
            $conn->begin_transaction();

            // Khoa cac san pham theo thu tu ID, tranh dat hang trung luc
            $lockedStock = [];
            $productIds = array_unique(array_column($items, "product_id"));
            sort($productIds, SORT_NUMERIC);
            foreach ($productIds as $productId) {
                $check = $conn->prepare("SELECT stock FROM sanpham WHERE id = ? FOR UPDATE");
                $check->bind_param("i", $productId);
                $check->execute();
                $stockRow = $check->get_result()->fetch_assoc();
                $check->close();
                if (!$stockRow) throw new Exception("Sản phẩm không còn tồn tại!");
                $lockedStock[$productId] = (int)$stockRow["stock"];
            }

            // San pham mua: tinh tong so luong cua tat ca dong trung ID
            $purchaseTotals = [];
            foreach ($items as $item) {
                if ($item["product_type"] === "mua") {
                    $id = $item["product_id"];
                    $purchaseTotals[$id] = ($purchaseTotals[$id] ?? 0) + $item["quantity"];
                }
            }
            foreach ($purchaseTotals as $id => $qty) {
                if ($qty > $lockedStock[$id]) throw new Exception("Không đủ tồn kho sản phẩm mua!");
            }

            // San pham thue: kiem tra moi ngay trong khoang [bat dau, ket thuc)
            // So sanh ca gio hang hien tai va cac don dang xu ly.
            foreach ($items as $item) {
                if ($item["product_type"] !== "thue") continue;
                $id = $item["product_id"];
                $startDate = $item["start_date"];
                $endDate = $item["end_date"];
                $booking = $conn->prepare(
                    "SELECT ct.quantity, ct.start_date, ct.end_date
                     FROM chitietdonhang ct
                     INNER JOIN donhang dh ON dh.id = ct.DonHang_id
                     WHERE ct.SanPham_id = ? AND ct.start_date < ? AND ct.end_date > ?
                       AND dh.status <> 'cancelled'"
                );
                $booking->bind_param("iss", $id, $endDate, $startDate);
                $booking->execute();
                $booked = $booking->get_result()->fetch_all(MYSQLI_ASSOC);
                $booking->close();
                $begin = new DateTimeImmutable($startDate);
                $finish = new DateTimeImmutable($endDate);
                for ($day = $begin; $day < $finish; $day = $day->modify("+1 day")) {
                    $d = $day->format("Y-m-d");
                    $used = 0;
                    foreach ($booked as $b) {
                        if ($b["start_date"] <= $d && $d < $b["end_date"]) $used += (int)$b["quantity"];
                    }
                    foreach ($items as $other) {
                        if ($other["product_type"] === "thue" && $other["product_id"] === $id
                            && $other["start_date"] <= $d && $d < $other["end_date"]) {
                            $used += $other["quantity"];
                        }
                    }
                    if ($used > $lockedStock[$id]) {
                        throw new Exception("Không đủ thiết bị cho lịch thuê đã chọn!");
                    }
                }
            }

            // Tao don hang
            $orderStmt = $conn->prepare(
                "INSERT INTO donhang
                 (NguoiDung_id, customer_name, customer_phone, customer_address, total_amount)
                 VALUES (?, ?, ?, ?, ?)"
            );

            $orderStmt->bind_param(
                "isssd",
                $checkoutUserId,
                $name,
                $phone,
                $address,
                $total
            );

            $orderStmt->execute();
            $orderId = $conn->insert_id;
            $orderStmt->close();

            // Luu chi tiet tung san pham
            $detailStmt = $conn->prepare(
                "INSERT INTO chitietdonhang
                 (DonHang_id, SanPham_id, quantity,
                  price, start_date, end_date)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );

            foreach ($items as $item) {
                $productId = $item["product_id"];
                $quantity = $item["quantity"];
                $price = $item["price"];
                $startDate = $item["start_date"];
                $endDate = $item["end_date"];
                $subtotal = $item["subtotal"];

                $detailStmt->bind_param(
                    "iiidss",
                    $orderId,
                    $productId,
                    $quantity,
                    $price,
                    $startDate,
                    $endDate
                );

                $detailStmt->execute();

                // Tru ton kho chi voi san pham mua
                if ($item["product_type"] === "mua") {
                    $update = $conn->prepare(
                        "UPDATE sanpham
                         SET stock = stock - ?
                         WHERE id = ? AND stock >= ?"
                    );

                    $update->bind_param(
                        "iii",
                        $quantity,
                        $productId,
                        $quantity
                    );

                    $update->execute();

                    if ($update->affected_rows !== 1) {
                        throw new Exception(
                            "Không thể cập nhật tồn kho!"
                        );
                    }

                    $update->close();
                }
            }

            $detailStmt->close();

            // Luu thanh cong
            $conn->commit();

            // Xoa gio hang sau khi dat hang
            $_SESSION["cart"] = [];
            $success = true;
            unset($_SESSION["checkout_csrf"]);

        } catch (Throwable $ex) {
            $conn->rollback();
            $error = "Đặt hàng thất bại. Vui lòng kiểm tra thông tin và thử lại.";
            error_log("FILMORY checkout: " . $ex->getMessage());
            $orderId = null;
        }
    }
}
?>

<?php include "header.php"; ?>

<style>
.checkout-page {
    max-width: 1150px;
    margin: 50px auto;
    padding: 20px;
}

.checkout-page h1 {
    font-size: 34px;
    margin-bottom: 30px;
}

.checkout-layout {
    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 35px;
}

.checkout-box {
    background: #fff;
    border: 1px solid #e5e5e5;
    border-radius: 12px;
    padding: 30px;
}

.checkout-box h2 {
    margin-bottom: 25px;
    font-size: 22px;
}

.checkout-form label {
    display: block;
    font-weight: 600;
    margin-bottom: 8px;
}

.checkout-form input,
.checkout-form textarea {
    width: 100%;
    padding: 13px;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 22px;
    font-size: 15px;
    box-sizing: border-box;
}

.checkout-form textarea {
    min-height: 110px;
    resize: vertical;
}

.checkout-btn {
    display: block;
    width: 100%;
    padding: 16px;
    background: #263c2b;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

.checkout-btn:hover {
    background: #17291c;
}

.checkout-item {
    padding: 15px 0;
    border-bottom: 1px solid #eee;
}

.checkout-item h3 {
    font-size: 16px;
    margin-bottom: 8px;
}

.checkout-item p {
    color: #666;
    font-size: 14px;
    margin: 5px 0;
}

.checkout-total {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 25px;
    font-size: 22px;
    font-weight: bold;
    color: #263c2b;
}

.checkout-alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 25px;
    background: #fff0f0;
    color: #a22222;
}

.checkout-success {
    text-align: center;
    padding: 55px 25px;
    background: #f2f7f1;
    border-radius: 15px;
}

.checkout-success h2 {
    color: #263c2b;
    font-size: 28px;
}

.checkout-success a {
    display: inline-block;
    padding: 13px 25px;
    margin-top: 20px;
    background: #263c2b;
    color: white;
    border-radius: 8px;
    text-decoration: none;
}

@media (max-width: 768px) {
    .checkout-layout {
        grid-template-columns: 1fr;
    }

    .checkout-page h1 {
        font-size: 27px;
    }
}
</style>

<main class="checkout-page">

    <h1>Thanh toán đơn hàng</h1>

    <?php if ($success): ?>

        <div class="checkout-success">
            <h2>Đặt hàng thành công!</h2>

            <p>
                Cảm ơn bạn đã đặt hàng tại FILMORY.
            </p>

            <p>
                Mã đơn hàng:
                <strong>#<?= (int)$orderId ?></strong>
            </p>

            <p>
                Tổng thanh toán:
                <strong><?= money($total) ?></strong>
            </p>

            <a href="my_orders.php">
                Xem đơn hàng của tôi
            </a>
            <a href="products.php" style="margin-left:10px">
                Tiếp tục mua sắm
            </a>
        </div>

    <?php else: ?>

        <?php if ($error): ?>
            <div class="checkout-alert">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <div class="checkout-layout">

            <!-- THONG TIN KHACH HANG -->
            <div class="checkout-box">
                <h2>Thông tin nhận hàng</h2>

                <form
                    class="checkout-form"
                    method="POST"
                    action="checkout.php"
                >
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION["checkout_csrf"]) ?>">

                    <label for="customer_name">
                        Họ và tên
                    </label>

                    <input
                        type="text"
                        id="customer_name"
                        name="customer_name"
                        value="<?= e($name) ?>"
                        maxlength="150"
                        placeholder="Nhập họ tên"
                        required
                    >

                    <label for="phone">
                        Số điện thoại
                    </label>

                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value="<?= e($phone) ?>"
                        placeholder="Ví dụ: 0901234567"
                        maxlength="11"
                        required
                    >

                    <label for="address">
                        Địa chỉ nhận hàng
                    </label>

                    <textarea
                        id="address"
                        name="address"
                        maxlength="255"
                        placeholder="Nhập địa chỉ nhận hàng"
                        required
                    ><?= e($address) ?></textarea>

                    <button
                        type="submit"
                        class="checkout-btn"
                        <?= $error !== "" && empty($items)
                            ? "disabled" : "" ?>
                    >
                        Xác nhận đặt hàng
                    </button>

                </form>
            </div>

            <!-- TOM TAT DON HANG -->
            <div class="checkout-box">
                <h2>Đơn hàng của bạn</h2>

                <?php foreach ($items as $item): ?>

                    <div class="checkout-item">
                        <h3>
                            <?= e($item["name"]) ?>
                        </h3>

                        <p>
                            Loại:
                            <?= $item["product_type"] === "thue"
                                ? "Cho thuê" : "Mua" ?>
                        </p>

                        <p>
                            Đơn giá:
                            <?= money($item["price"]) ?>
                        </p>

                        <p>
                            Số lượng:
                            <?= (int)$item["quantity"] ?>
                        </p>

                        <?php if (
                            $item["product_type"] === "thue"
                        ): ?>
                            <p>
                                Từ ngày:
                                <?= e($item["start_date"]) ?>
                            </p>

                            <p>
                                Đến ngày:
                                <?= e($item["end_date"]) ?>
                            </p>

                            <p>
                                Số ngày thuê:
                                <?= (int)$item["days"] ?>
                            </p>
                        <?php endif; ?>

                        <p>
                            Thành tiền:
                            <strong>
                                <?= money($item["subtotal"]) ?>
                            </strong>
                        </p>
                    </div>

                <?php endforeach; ?>

                <div class="checkout-total">
                    <span>Tổng cộng</span>
                    <span><?= money($total) ?></span>
                </div>

                <p style="margin-top:25px">
                    <a href="cart.php">
                        ← Quay lại giỏ hàng
                    </a>
                </p>
            </div>

        </div>

    <?php endif; ?>

</main>

<?php include "footer.php"; ?>
