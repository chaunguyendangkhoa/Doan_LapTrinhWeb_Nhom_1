<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
if (auth_logged_in()) {
    header('Location: index.php');
    exit;
}
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');
    if (!auth_csrf_valid()) {
        $error = 'Phiên biểu mẫu không hợp lệ. Vui lòng tải lại trang.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        $error = 'Tên đăng nhập phải có 3–50 ký tự, chỉ gồm chữ không dấu, số và dấu gạch dưới.';
    } elseif (strlen($password) < 8 || strlen($password) > 72) {
        $error = 'Mật khẩu phải có từ 8 đến 72 ký tự.';
    } elseif ($password !== $confirm) {
        $error = 'Mật khẩu xác nhận không khớp.';
    } else {
        $stmt = $conn->prepare('SELECT id FROM nguoidung WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($exists) {
            $error = 'Tên đăng nhập đã tồn tại.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'user';
            try {
                $stmt = $conn->prepare('INSERT INTO nguoidung (username, password, role) VALUES (?, ?, ?)');
                $stmt->bind_param('sss', $username, $hash, $role);
                $stmt->execute();
                $stmt->close();
                header('Location: login.php?registered=1');
                exit;
            } catch (mysqli_sql_exception $e) {
                if ((int)$e->getCode() === 1062) {
                    $error = 'Tên đăng nhập đã tồn tại.';
                } else {
                    error_log('FILMORY register: ' . $e->getMessage());
                    $error = 'Không thể đăng ký lúc này. Vui lòng thử lại.';
                }
            }
        }
    }
}
include __DIR__ . '/header.php';
?>
<link rel="stylesheet" href="assets/css/auth.css?v=1">
<main class="auth-page"><section class="auth-card">
<p class="auth-eyebrow">FILMORY • THÀNH VIÊN MỚI</p><h1>Đăng ký</h1>
<p class="auth-subtitle">Tạo tài khoản để đồng hành cùng FILMORY.</p>
<?php if ($error !== ''): ?><div class="auth-error" role="alert"><?= auth_e($error) ?></div><?php endif; ?>
<form method="post" action="register.php">
<input type="hidden" name="csrf_token" value="<?= auth_e($_SESSION['csrf_token']) ?>">
<label for="username">Tên đăng nhập</label><input id="username" name="username" minlength="3" maxlength="50" pattern="[A-Za-z0-9_]+" required autocomplete="username" value="<?= auth_e($username) ?>">
<label for="password">Mật khẩu (ít nhất 8 ký tự)</label><input id="password" name="password" type="password" minlength="8" maxlength="72" required autocomplete="new-password">
<label for="confirm_password">Nhập lại mật khẩu</label><input id="confirm_password" name="confirm_password" type="password" minlength="8" maxlength="72" required autocomplete="new-password">
<button type="submit">Tạo tài khoản</button>
</form><p class="auth-bottom">Đã có tài khoản? <a href="login.php">Đăng nhập</a></p>
</section></main>
<?php include __DIR__ . '/footer.php'; ?>
