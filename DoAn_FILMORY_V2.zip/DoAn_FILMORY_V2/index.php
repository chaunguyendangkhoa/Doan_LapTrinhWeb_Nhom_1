<?php
require_once __DIR__ . '/config/database.php';

$featuredProducts = [];
$query = $conn->query('SELECT id, name, description, price, product_type, image, stock FROM sanpham ORDER BY id DESC LIMIT 6');
if ($query) {
    while ($item = $query->fetch_assoc()) {
        $featuredProducts[] = $item;
    }
}

function safeText($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

function productImagePath($image) {
    $image = trim((string)$image);
    if ($image === '') return '';
    if (preg_match('~^https?://~i', $image)) return $image;
    if (strpos($image, 'assets/') === 0) return $image;
    return 'assets/images/' . basename($image);
}

include 'header.php';
?>
<section class="hero hero-viet">
    <div class="hero-content">
        <p class="eyebrow">DI SẢN • KHOẢNH KHẮC • SÁNG TẠO</p>
        <h1>Máy ảnh cho những hành trình<br><span class="hero-viet-accent">đậm chất Việt.</span></h1>
        <p class="hero-description">Từ mái ngói phố cổ đến những con đường quê hương, hãy lưu giữ từng khoảnh khắc cùng FILMORY — nơi thiết bị hiện đại gặp gỡ vẻ đẹp truyền thống.</p>
        <div class="hero-buttons">
            <a class="btn-primary" href="products.php">Khám phá ngay →</a>
            <a class="btn-secondary" href="products.php?type=thue">Thuê máy ảnh</a>
        </div>
        <div class="hero-note"><span>✦</span> Gìn giữ nét Việt qua từng khung hình</div>
    </div>
    <div class="hero-image">
        <img src="assets/images/vietnam-hero.png" alt="Không gian Việt cổ với máy ảnh và đèn lồng">
        <div class="image-label">
            <span>FILMORY • GÓC NHÌN VIỆT</span>
            <strong>Mỗi khung hình, một câu chuyện.</strong>
        </div>
    </div>
</section>

<section class="categories section">
    <div class="section-heading">
        <div><p class="eyebrow">KHÁM PHÁ FILMORY</p><h2>Tinh hoa thiết bị nhiếp ảnh</h2></div>
        <a class="view-all" href="products.php">Xem tất cả ↗</a>
    </div>
    <div class="category-grid">
        <a class="category-card" href="products.php?category=1">
            <img src="assets/images/vietnam-hero.png" alt="Máy ảnh">
            <div class="category-overlay"><span>01 / MÁY ẢNH</span><h3>Máy ảnh</h3><p>Lưu giữ từng khoảnh khắc →</p></div>
        </a>
        <a class="category-card" href="products.php?category=2">
            <img src="assets/images/vietnam-hero.png" alt="Ống kính">
            <div class="category-overlay"><span>02 / ỐNG KÍNH</span><h3>Ống kính</h3><p>Khám phá góc nhìn mới →</p></div>
        </a>
        <a class="category-card" href="products.php?category=3">
            <img src="assets/images/vietnam-hero.png" alt="Phụ kiện">
            <div class="category-overlay"><span>03 / PHỤ KIỆN</span><h3>Phụ kiện</h3><p>Đồng hành cùng sáng tạo →</p></div>
        </a>
    </div>
</section>

<section class="featured section">
    <div class="section-heading">
        <div>
            <p class="eyebrow">BỘ SƯU TẬP FILMORY</p>
            <h2>Sản phẩm nổi bật</h2>
            <p class="section-description">Thiết bị có sẵn trong cửa hàng, cập nhật từ cơ sở dữ liệu.</p>
        </div>
        <a href="products.php" class="view-all">Khám phá sản phẩm ↗</a>
    </div>
    <div class="product-grid">
        <?php foreach ($featuredProducts as $p): ?>
            <article class="product-card">
                <a class="product-image" href="product_detail.php?id=<?= (int)$p['id'] ?>">
                    <?php $src = productImagePath($p['image']); ?>
                    <?php if ($src !== ''): ?>
                        <img src="<?= safeText($src) ?>" alt="<?= safeText($p['name']) ?>" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                        <span class="filmory-fallback" style="display:none">📷<small>Chưa có ảnh sản phẩm</small></span>
                    <?php else: ?>
                        <span class="filmory-fallback">📷<small>Chưa có ảnh sản phẩm</small></span>
                    <?php endif; ?>
                    <span class="product-tag <?= $p['product_type'] === 'mua' ? 'sale-tag' : '' ?>">
                        <?= $p['product_type'] === 'thue' ? 'CHO THUÊ' : 'MUA SẢN PHẨM' ?>
                    </span>
                </a>
                <div class="product-info">
                    <p class="product-type">FILMORY COLLECTION</p>
                    <h3><?= safeText($p['name']) ?></h3>
                    <div class="product-bottom">
                        <p><strong><?= number_format((float)$p['price'], 0, ',', '.') ?>đ</strong><?= $p['product_type'] === 'thue' ? ' / ngày' : '' ?></p>
                        <a href="product_detail.php?id=<?= (int)$p['id'] ?>" aria-label="Xem chi tiết">↗</a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
        <?php if (!$featuredProducts): ?>
            <p>Chưa có sản phẩm. Vui lòng kiểm tra bảng sanpham trong database doan.</p>
        <?php endif; ?>
    </div>
</section>

<section class="story">
    <div class="story-image"><img src="assets/images/vietnam-hero.png" alt="Không gian Việt cổ và nghệ thuật nhiếp ảnh"></div>
    <div class="story-content">
        <p class="eyebrow">HỒN VIỆT TRONG TỪNG KHUNG HÌNH</p>
        <h2>Không chỉ là máy ảnh, đó là những câu chuyện...</h2>
        <p>FILMORY đồng hành cùng bạn trên hành trình lưu giữ nét đẹp văn hóa Việt Nam, từ những điều bình dị nhất đến những khoảnh khắc không thể quên.</p>
        <a href="products.php" class="btn-primary">Bắt đầu hành trình →</a>
    </div>
</section>

<section class="benefits">
    <div class="benefit"><span>01</span><h3>Thiết bị đa dạng</h3><p>Lựa chọn máy ảnh, ống kính và phụ kiện phù hợp.</p></div>
    <div class="benefit"><span>02</span><h3>Thuê và mua dễ dàng</h3><p>Khám phá thiết bị theo nhu cầu và ngân sách.</p></div>
    <div class="benefit"><span>03</span><h3>Thỏa sức sáng tạo</h3><p>Ghi lại câu chuyện của riêng bạn qua từng khung hình.</p></div>
</section>
<?php include 'footer.php'; ?>
