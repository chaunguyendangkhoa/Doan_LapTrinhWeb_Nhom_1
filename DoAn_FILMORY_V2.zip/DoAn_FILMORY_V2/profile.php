<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
if (!auth_logged_in()) {
    header('Location: login.php');
    exit;
}
$userId = (int)$_SESSION['user_id'];
function customer_money($n) { return number_format((float)$n, 0, ',', '.') . 'đ'; }

$message = '';
$ok = false;
$stmt = $conn->prepare('SELECT id, username, password, role, created_at FROM nguoidung WHERE id = ?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$user) { header('Location: logout.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!auth_csrf_valid()) {
        $message = 'Phiên biểu mẫu không hợp lệ, hãy tải lại trang.';
    } else {
        $old = (string)($_POST['old_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');
        if (!password_verify($old, $user['password'])) {
            $message = 'Mật khẩu hiện tại không đúng.';
        } elseif (strlen($new) < 8 || strlen($new) > 72) {
            $message = 'Mật khẩu mới cần từ 8 đến 72 ký tự.';
        } elseif ($new !== $confirm) {
            $message = 'Mật khẩu xác nhận không khớp.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $update = $conn->prepare('UPDATE nguoidung SET password = ? WHERE id = ?');
            $update->bind_param('si', $hash, $userId);
            $update->execute();
            $update->close();
            $ok = true;
            $message = 'Đổi mật khẩu thành công.';
        }
    }
}
include __DIR__ . '/header.php';
?>
<link rel="stylesheet" href="assets/css/customer.css">
<main class="customer-page">
<h1>Tài khoản của tôi</h1>
<div class="customer-grid">
<section class="customer-panel"><h2>Thông tin tài khoản</h2>
<p><strong>Tên đăng nhập:</strong> <?= auth_e($user['username']) ?></p>
<p><strong>Ngày đăng ký:</strong> <?= auth_e($user['created_at']) ?></p>
<p><strong>Vai trò:</strong> <?= auth_e($user['role']) ?></p>
<a class="customer-btn" href="my_orders.php">Xem đơn hàng của tôi</a></section>
<section class="customer-panel"><h2>Đổi mật khẩu</h2>
<?php if ($message): ?><div class="customer-alert <?= $ok ? 'customer-ok' : '' ?>"><?= auth_e($message) ?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= auth_e($_SESSION['csrf_token']) ?>">
<label>Mật khẩu hiện tại</label><input type="password" name="old_password" required autocomplete="current-password">
<label>Mật khẩu mới (ít nhất 8 ký tự)</label><input type="password" name="new_password" required minlength="8" autocomplete="new-password">
<label>Nhập lại mật khẩu mới</label><input type="password" name="confirm_password" required minlength="8" autocomplete="new-password">
<button class="customer-btn" type="submit">Đổi mật khẩu</button></form></section>
</div></main>
<?php include __DIR__ . '/footer.php'; ?>
