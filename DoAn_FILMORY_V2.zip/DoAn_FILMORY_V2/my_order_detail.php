
<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';

// Kiểm tra đăng nhập
if (!auth_logged_in()) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Định dạng tiền
function customer_money($n) {
    return number_format((float)$n, 0, ',', '.') . 'đ';
}

// Kiểm tra mã đơn hàng
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(404);
    exit('Không tìm thấy đơn hàng.');
}

// Chỉ lấy đơn hàng thuộc tài khoản đang đăng nhập
$stmt = $conn->prepare("
    SELECT
        id,
        customer_name,
        customer_phone,
        customer_address,
        total_amount,
        status,
        order_date
    FROM donhang
    WHERE id = ?
      AND NguoiDung_id = ?
    LIMIT 1
");

$stmt->bind_param('ii', $id, $userId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    http_response_code(404);
    exit('Không tìm thấy đơn hàng hoặc bạn không có quyền xem.');
}

// Lấy sản phẩm trong đơn và trạng thái bàn giao
$stmt = $conn->prepare("
    SELECT
        ct.id,
        ct.quantity,
        ct.price,
        ct.start_date,
        ct.end_date,
        sp.name,
        sp.product_type,
        bg.trang_thai AS rental_status,
        bg.ngay_giao,
        bg.ngay_tra
    FROM chitietdonhang ct

    LEFT JOIN sanpham sp
        ON sp.id = ct.SanPham_id

    LEFT JOIN ban_giao_thue bg
        ON bg.ChiTietDonHang_id = ct.id

    WHERE ct.DonHang_id = ?
    ORDER BY ct.id
");

$stmt->bind_param('i', $id);
$stmt->execute();
$details = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Trạng thái đơn hàng
$labels = [
    'pending' => 'Chờ xác nhận',
    'processing' => 'Đang xử lý',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy'
];

// Trạng thái bàn giao
$rentalLabels = [
    'cho_nhan' => 'Chờ nhận thiết bị',
    'da_giao' => 'Đã nhận thiết bị',
    'da_tra' => 'Đã trả thiết bị'
];

$statusClass = [
    'pending' => 'pending',
    'processing' => 'processing',
    'completed' => 'completed',
    'cancelled' => 'cancelled'
];

include __DIR__ . '/header.php';
?>

<link rel="stylesheet" href="assets/css/customer.css">

<style>
/* Giao diện chi tiết đơn hàng FILMORY */

.filmory-order-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 24px;
}

.filmory-order-heading h1 {
    margin: 0;
}

.filmory-order-status {
    display: inline-block;
    padding: 9px 16px;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 600;
    background: #f2e2c6;
    color: #74442e;
}

.filmory-order-status.completed {
    background: #e0efdf;
    color: #28653b;
}

.filmory-order-status.cancelled {
    background: #f7dddd;
    color: #a52d2d;
}

.filmory-order-status.processing {
    background: #e1eaf7;
    color: #28558b;
}

.filmory-info-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.filmory-info-box {
    padding: 22px;
    background: #fffaf1;
    border: 1px solid #e8d7bc;
    border-radius: 12px;
}

.filmory-info-box h2 {
    font-size: 20px;
    margin: 0 0 16px;
    color: #633c29;
}

.filmory-info-box p {
    margin: 10px 0;
    line-height: 1.7;
}

.filmory-detail-table {
    width: 100%;
    border-collapse: collapse;
}

.filmory-detail-table th,
.filmory-detail-table td {
    padding: 15px 12px;
    text-align: left;
    border-bottom: 1px solid #eadcc8;
    vertical-align: top;
}

.filmory-detail-table th {
    background: #f3e6d0;
    color: #573322;
}

.filmory-product-name {
    font-weight: 600;
    color: #513222;
}

.filmory-type {
    display: inline-block;
    margin-top: 7px;
    padding: 4px 9px;
    border-radius: 5px;
    background: #f1e3cc;
    font-size: 12px;
    color: #74442e;
}

.filmory-rental-info {
    margin-top: 8px;
    font-size: 13px;
    line-height: 1.8;
    color: #705c4c;
}

.filmory-total {
    margin-top: 25px;
    padding: 22px;
    background: #f4e6cf;
    border-radius: 10px;
    text-align: right;
}

.filmory-total p {
    margin: 0 0 8px;
}

.filmory-total strong {
    font-size: 26px;
    color: #923126;
}

.filmory-order-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 25px;
}

.filmory-order-actions a {
    text-decoration: none;
}

.filmory-secondary-btn {
    display: inline-block;
    padding: 12px 18px;
    border: 1px solid #9b6b49;
    border-radius: 6px;
    color: #69402c;
}

@media (max-width: 768px) {
    .filmory-info-grid {
        grid-template-columns: 1fr;
    }

    .filmory-detail-table {
        min-width: 720px;
    }

    .filmory-total {
        text-align: left;
    }
}
</style>

<main class="customer-page">

    <div class="filmory-order-heading">

        <h1>
            Chi tiết đơn hàng #<?= (int)$id ?>
        </h1>

        <span class="filmory-order-status <?= auth_e($statusClass[$order['status']] ?? '') ?>">
            <?= auth_e($labels[$order['status']] ?? $order['status']) ?>
        </span>

    </div>

    <div class="filmory-info-grid">

        <section class="filmory-info-box">

            <h2>Thông tin đơn hàng</h2>

            <p>
                <strong>Mã đơn:</strong>
                #<?= (int)$order['id'] ?>
            </p>

            <p>
                <strong>Ngày đặt:</strong>
                <?= auth_e($order['order_date']) ?>
            </p>

            <p>
                <strong>Trạng thái:</strong>
                <?= auth_e($labels[$order['status']] ?? $order['status']) ?>
            </p>

        </section>

        <section class="filmory-info-box">

            <h2>Thông tin khách hàng</h2>

            <p>
                <strong>Người nhận:</strong>
                <?= auth_e($order['customer_name']) ?>
            </p>

            <p>
                <strong>Số điện thoại:</strong>
                <?= auth_e($order['customer_phone']) ?>
            </p>

            <p>
                <strong>Địa chỉ:</strong>
                <?= nl2br(auth_e($order['customer_address'])) ?>
            </p>

        </section>

    </div>

    <section class="customer-panel">

        <h2>Sản phẩm trong đơn hàng</h2>

        <div class="customer-scroll">

            <table class="filmory-detail-table">

                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Đơn giá</th>
                        <th>Thông tin thuê</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($details as $detail): ?>

                    <?php
                    $isRental = (
                        $detail['product_type'] === 'thue'
                        || (
                            !empty($detail['start_date'])
                            && !empty($detail['end_date'])
                        )
                    );

                    $days = 1;

                    if (
                        $isRental
                        && !empty($detail['start_date'])
                        && !empty($detail['end_date'])
                    ) {
                        try {
                            $start = new DateTimeImmutable(
                                $detail['start_date']
                            );

                            $end = new DateTimeImmutable(
                                $detail['end_date']
                            );

                            $days = max(
                                1,
                                (int)$start->diff($end)->days
                            );
                        } catch (Exception $e) {
                            $days = 1;
                        }
                    }

                    $quantity = (int)$detail['quantity'];
                    $price = (float)$detail['price'];
                    $lineTotal = $price * $quantity * $days;

                    $rentalStatus = $detail['rental_status'];

                    if ($rentalStatus === null) {
                        $rentalStatus = 'cho_nhan';
                    }
                    ?>

                    <tr>

                        <td>

                            <div class="filmory-product-name">
                                <?= auth_e($detail['name'] ?? 'Sản phẩm đã xóa') ?>
                            </div>

                            <span class="filmory-type">
                                <?= $isRental ? 'Cho thuê' : 'Mua sản phẩm' ?>
                            </span>

                        </td>

                        <td>
                            <?= $quantity ?>
                        </td>

                        <td>
                            <?= customer_money($price) ?>
                            <?= $isRental ? '/ngày' : '' ?>
                        </td>

                        <td>

                            <?php if ($isRental): ?>

                                <div class="filmory-rental-info">

                                    <div>
                                        <strong>Bắt đầu:</strong>
                                        <?= auth_e($detail['start_date'] ?? '—') ?>
                                    </div>

                                    <div>
                                        <strong>Kết thúc:</strong>
                                        <?= auth_e($detail['end_date'] ?? '—') ?>
                                    </div>

                                    <div>
                                        <strong>Thời gian:</strong>
                                        <?= $days ?> ngày
                                    </div>

                                    <div>
                                        <strong>Bàn giao:</strong>
                                        <?php if ($order['status'] === 'cancelled'): ?>
                                            Đơn đã hủy
                                        <?php else: ?>
                                            <?= auth_e(
                                                $rentalLabels[$rentalStatus]
                                                ?? 'Chờ cập nhật'
                                            ) ?>
                                        <?php endif; ?>
                                    </div>

                                    <?php if (!empty($detail['ngay_giao'])): ?>
                                        <div>
                                            <strong>Ngày giao:</strong>
                                            <?= auth_e($detail['ngay_giao']) ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (!empty($detail['ngay_tra'])): ?>
                                        <div>
                                            <strong>Ngày trả:</strong>
                                            <?= auth_e($detail['ngay_tra']) ?>
                                        </div>
                                    <?php endif; ?>

                                </div>

                            <?php else: ?>

                                Không áp dụng

                            <?php endif; ?>

                        </td>

                        <td>
                            <strong>
                                <?= customer_money($lineTotal) ?>
                            </strong>
                        </td>

                    </tr>

                <?php endforeach; ?>

                <?php if (!$details): ?>
                    <tr>
                        <td colspan="5">
                            Không tìm thấy chi tiết sản phẩm.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div class="filmory-total">

            <p>Tổng thanh toán của đơn hàng</p>

            <strong>
                <?= customer_money($order['total_amount']) ?>
            </strong>

        </div>

        <div class="filmory-order-actions">

            <a class="customer-btn" href="my_orders.php">
                ← Quay lại đơn hàng
            </a>

            <a class="filmory-secondary-btn" href="products.php">
                Tiếp tục mua sắm
            </a>

        </div>

    </section>

</main>

<?php include __DIR__ . '/footer.php'; ?>
