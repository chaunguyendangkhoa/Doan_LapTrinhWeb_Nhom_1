-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 28, 2026 lúc 10:49 AM
-- Phiên bản máy phục vụ: 10.11.16-MariaDB
-- Phiên bản PHP: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `filmory_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chitietdonhang`
--

CREATE TABLE `chitietdonhang` (
  `id` int(11) NOT NULL,
  `DonHang_id` int(11) NOT NULL,
  `SanPham_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmucsanpham`
--

CREATE TABLE `danhmucsanpham` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danhmucsanpham`
--

INSERT INTO `danhmucsanpham` (`id`, `name`, `description`) VALUES
(1, 'Máy ảnh', 'Máy ảnh cho thuê'),
(2, 'Trang phục', 'Trang phục cho thuê để chụp ảnh'),
(3, 'Phụ kiện cho thuê', 'Phụ kiện hỗ trợ chụp ảnh'),
(4, 'Phụ kiện bán', 'Phụ kiện máy ảnh được bán');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `donhang`
--

CREATE TABLE `donhang` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `customer_address` text NOT NULL,
  `total_amount` bigint(20) NOT NULL,
  `status` enum('pending','processing','completed','cancelled') DEFAULT 'pending',
  `order_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoidung`
--

CREATE TABLE `nguoidung` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `DanhMucSanPham_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `product_type` enum('thue','mua') NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`id`, `DanhMucSanPham_id`, `name`, `description`, `price`, `product_type`, `image`, `stock`, `created_at`) VALUES
(1, 1, 'Chào Mọi Người', 'Máy ảnh phù hợp chụp ảnh và quay video', 150000, 'thue', NULL, 5, '2026-10-28 16:18:11'),
(2, 1, 'Sony A6400', 'Máy ảnh mirrorless cho chụp ảnh và quay phim', 250000, 'thue', NULL, 3, '2026-10-28 16:18:11'),
(3, 1, 'Fujifilm X-T30', 'Máy ảnh phong cách retro', 220000, 'thue', NULL, 3, '2026-10-28 16:18:11'),
(4, 1, 'Canon EOS 200D II', 'Máy ảnh DSLR cho người mới bắt đầu', 180000, 'thue', NULL, 4, '2026-10-28 16:18:11'),
(5, 1, 'Sony ZV-E10', 'Máy ảnh phù hợp quay vlog', 230000, 'thue', NULL, 4, '2026-10-28 16:18:11'),
(6, 1, 'Fujifilm X-S10', 'Máy ảnh hỗ trợ chống rung', 280000, 'thue', NULL, 2, '2026-10-28 16:18:11'),
(7, 1, 'Nikon D5600', 'Máy ảnh DSLR dùng chụp ảnh chân dung', 170000, 'thue', NULL, 3, '2026-10-28 16:18:11'),
(8, 1, 'Kodak M35', 'Máy ảnh film nhỏ gọn', 60000, 'thue', NULL, 8, '2026-10-28 16:18:11'),
(9, 2, 'Váy vintage trắng', 'Váy trắng dùng chụp ảnh ngoài trời', 80000, 'thue', NULL, 5, '2026-10-28 16:18:11'),
(10, 2, 'Váy hoa phong cách Hàn Quốc', 'Váy hoa dành cho bộ ảnh nhẹ nhàng', 100000, 'thue', NULL, 4, '2026-10-28 16:18:11'),
(11, 2, 'Áo sơ mi vintage', 'Áo sơ mi phong cách cổ điển', 50000, 'thue', NULL, 6, '2026-10-28 16:18:11'),
(12, 2, 'Vest chụp ảnh nam', 'Vest dùng chụp ảnh chân dung', 120000, 'thue', NULL, 3, '2026-10-28 16:18:11'),
(13, 2, 'Mũ beret vintage', 'Mũ phụ kiện cho bộ ảnh vintage', 30000, 'thue', NULL, 8, '2026-10-28 16:18:11'),
(14, 3, 'Bó hoa cầm tay', 'Hoa trang trí khi chụp ảnh', 40000, 'thue', NULL, 6, '2026-10-28 16:18:11'),
(15, 3, 'Chân máy ảnh tripod', 'Chân máy hỗ trợ giữ máy ảnh', 50000, 'thue', NULL, 5, '2026-10-28 16:18:11'),
(16, 3, 'Đèn LED chụp ảnh', 'Đèn hỗ trợ chiếu sáng', 70000, 'thue', NULL, 4, '2026-10-28 16:18:11'),
(17, 4, 'Thẻ nhớ SD 64GB', 'Thẻ nhớ lưu ảnh và video', 250000, 'mua', NULL, 10, '2026-10-28 16:18:11'),
(18, 4, 'Túi đựng máy ảnh', 'Túi bảo vệ máy ảnh khi di chuyển', 180000, 'mua', NULL, 8, '2026-10-28 16:18:11'),
(19, 4, 'Dây đeo máy ảnh vintage', 'Dây đeo máy ảnh phong cách cổ điển', 90000, 'mua', NULL, 10, '2026-10-28 16:18:11'),
(20, 4, 'Bộ vệ sinh máy ảnh', 'Bộ dụng cụ vệ sinh máy ảnh', 120000, 'mua', NULL, 10, '2026-10-28 16:18:11'),
(21, 4, 'Pin máy ảnh tương thích', 'Pin thay thế tương thích với thiết bị', 220000, 'mua', NULL, 6, '2026-10-28 16:18:11'),
(22, 4, 'Đầu đọc thẻ nhớ USB', 'Thiết bị đọc dữ liệu từ thẻ nhớ', 100000, 'mua', NULL, 8, '2026-10-28 16:18:11'),
(23, 4, 'Filter bảo vệ ống kính', 'Kính lọc bảo vệ mặt trước ống kính', 150000, 'mua', NULL, 6, '2026-10-28 16:18:11'),
(24, 4, 'Album ảnh mini', 'Album lưu giữ ảnh in', 80000, 'mua', NULL, 12, '2026-10-28 16:18:11');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chitietdonhang`
--
ALTER TABLE `chitietdonhang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `DonHang_id` (`DonHang_id`),
  ADD KEY `SanPham_id` (`SanPham_id`);

--
-- Chỉ mục cho bảng `danhmucsanpham`
--
ALTER TABLE `danhmucsanpham`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `DanhMucSanPham_id` (`DanhMucSanPham_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chitietdonhang`
--
ALTER TABLE `chitietdonhang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `danhmucsanpham`
--
ALTER TABLE `danhmucsanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `donhang`
--
ALTER TABLE `donhang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Ràng buộc đối với các bảng kết xuất
--

--
-- Ràng buộc cho bảng `chitietdonhang`
--
ALTER TABLE `chitietdonhang`
  ADD CONSTRAINT `chitietdonhang_ibfk_1` FOREIGN KEY (`DonHang_id`) REFERENCES `donhang` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chitietdonhang_ibfk_2` FOREIGN KEY (`SanPham_id`) REFERENCES `sanpham` (`id`) ON DELETE CASCADE;

--
-- Ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`DanhMucSanPham_id`) REFERENCES `danhmucsanpham` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
