
<?php
require_once __DIR__ . '/config/auth.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$filterType = $_GET['type'] ?? '';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>FILMORY | Lưu giữ khoảnh khắc Việt</title>

    <!-- Font tiếng Việt -->
    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700&family=Noto+Serif:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet"
    >

    <!-- CSS giao diện chính -->
    <link rel="stylesheet"
          href="assets/css/style.css?v=20261028">

    <!-- CSS sửa font tiếng Việt -->
    <link rel="stylesheet"
          href="assets/css/font-fix.css?v=3">
</head>

<body>

<div class="top-bar">
    ✦ FILMORY — LƯU GIỮ KHOẢNH KHẮC VIỆT ✦
</div>

<header class="header">

    <a href="index.php" class="logo">
        FILMORY<span>.</span>
        <small>Lưu giữ khoảnh khắc Việt</small>
    </a>

    <nav aria-label="Điều hướng chính">

        <a href="index.php"
           class="<?= $currentPage === 'index.php'
               ? 'active' : '' ?>">
            Trang chủ
        </a>

        <a href="products.php"
           class="<?= $currentPage === 'products.php'
               && ($filterType === ''
               || $filterType === 'all')
               ? 'active' : '' ?>">
            Sản phẩm
        </a>

        <a href="products.php?type=thue"
           class="<?= $currentPage === 'products.php'
               && $filterType === 'thue'
               ? 'active' : '' ?>">
            Cho thuê
        </a>

        <a href="products.php?type=mua"
           class="<?= $currentPage === 'products.php'
               && $filterType === 'mua'
               ? 'active' : '' ?>">
            Mua thiết bị
        </a>

    </nav>

    <div class="header-actions">

        <a href="cart.php" class="cart-link">
            Giỏ hàng 🛒
        </a>

        <?php if (auth_logged_in()): ?>

            <a href="profile.php" class="cart-link">
                Tài khoản của tôi
            </a>

            <a href="my_orders.php" class="cart-link">
                Đơn hàng của tôi
            </a>

            <span class="auth-username">
                Xin chào,
                <?= auth_e($_SESSION['username'] ?? '') ?>
            </span>

            <form action="logout.php"
                  method="post"
                  class="auth-logout-form">

                <input type="hidden"
                       name="csrf_token"
                       value="<?= auth_e($_SESSION['csrf_token']) ?>">

                <button type="submit" class="login-btn">
                    Đăng xuất
                </button>

            </form>

        <?php else: ?>

            <a href="login.php" class="login-btn">
                Đăng nhập
            </a>

        <?php endif; ?>

    </div>

</header>
