
<?php
require_once __DIR__ . "/config/auth.php";
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/rental.php";

// Kiem tra ket noi MySQL
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Loi ket noi database.php: chua co bien $conn");
}

// Lay ID san pham tu URL
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id <= 0) {
    http_response_code(400);
    die("Ma san pham khong hop le!");
}

// Lay san pham va ten danh muc
$sql = "SELECT sanpham.*,
               danhmucsanpham.name AS category_name
        FROM sanpham
        LEFT JOIN danhmucsanpham
          ON sanpham.DanhMucSanPham_id = danhmucsanpham.id
        WHERE sanpham.id = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    http_response_code(404);
    die("Khong tim thay san pham!");
}

// Ham chong XSS
function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

// Dinh dang tien Viet Nam
function money($price) {
    return number_format((float)$price, 0, ",", ".") . "đ";
}

$isRent = $product["product_type"] === "thue";
$stock = (int)$product["stock"];
$today = date("Y-m-d");
if (($_GET['check_availability'] ?? '') === '1') {
    header('Content-Type: application/json; charset=utf-8');
    $start = (string)($_GET['start_date'] ?? '');
    $end = (string)($_GET['end_date'] ?? '');
    $available = rental_available($conn, (int)$product['id'], $start, $end, $stock, $_SESSION['cart'] ?? []);
    echo json_encode(['available'=>$available,'days'=>rental_days_valid($start,$end)], JSON_UNESCAPED_UNICODE);
    exit;
}
?>

<?php include "header.php"; ?>

<style>
.detail-page {
    max-width: 1150px;
    margin: 45px auto;
    padding: 20px;
}

.detail-back {
    display: inline-block;
    margin-bottom: 25px;
    color: #555;
    text-decoration: none;
}

.detail-layout {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 45px;
    align-items: start;
}

.detail-image {
    background: #f4f4f0;
    border-radius: 18px;
    overflow: hidden;
    min-height: 420px;
}

.detail-image img {
    width: 100%;
    height: 460px;
    object-fit: cover;
    display: block;
}

.detail-no-image {
    height: 460px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 38px;
    font-weight: bold;
    color: #777;
}

.detail-info h1 {
    font-size: 34px;
    margin: 15px 0;
}

.detail-category {
    color: #777;
    text-transform: uppercase;
    letter-spacing: 2px;
    font-size: 12px;
}

.detail-badge {
    display: inline-block;
    background: #e9eee8;
    color: #315b40;
    border-radius: 20px;
    padding: 7px 15px;
    font-size: 13px;
}

.detail-price {
    margin: 22px 0;
    font-size: 30px;
    font-weight: bold;
    color: #263c2b;
}

.detail-price small {
    font-size: 15px;
    color: #777;
    font-weight: normal;
}

.detail-description {
    color: #666;
    line-height: 1.8;
    margin-bottom: 25px;
}

.detail-stock {
    margin-bottom: 25px;
    font-weight: 500;
}

.detail-form label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
}

.detail-form input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 18px;
    font-size: 15px;
    box-sizing: border-box;
}

.detail-form input[type="number"] {
    max-width: 130px;
}

.detail-dates {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.detail-add-btn {
    width: 100%;
    padding: 16px;
    border: none;
    background: #263c2b;
    color: white;
    border-radius: 9px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

.detail-add-btn:hover {
    background: #17291c;
}

.detail-add-btn:disabled {
    background: #999;
    cursor: not-allowed;
}

.detail-links {
    display: flex;
    gap: 20px;
    margin-top: 20px;
}

.detail-links a {
    color: #315b40;
    text-decoration: none;
}

@media (max-width: 768px) {
    .detail-layout {
        grid-template-columns: 1fr;
        gap: 25px;
    }

    .detail-info h1 {
        font-size: 27px;
    }

    .detail-image,
    .detail-image img,
    .detail-no-image {
        min-height: 300px;
        height: 320px;
    }

    .detail-dates {
        grid-template-columns: 1fr;
        gap: 0;
    }
}
</style>

<main class="detail-page">

    <a href="products.php" class="detail-back">
        ← Quay lại danh sách sản phẩm
    </a>

    <div class="detail-layout">

        <!-- HINH ANH SAN PHAM -->
        <div class="detail-image">
            <?php if (!empty($product["image"])): ?>
                <img
                    src="assets/images/<?= e($product['image']) ?>"
                    alt="<?= e($product['name']) ?>"
                    onerror="this.style.display='none'"
                >
            <?php else: ?>
                <div class="detail-no-image">
                    FILMORY
                </div>
            <?php endif; ?>
        </div>

        <!-- THONG TIN SAN PHAM -->
        <div class="detail-info">

            <p class="detail-category">
                <?= e($product["category_name"] ?? "Chưa phân loại") ?>
            </p>

            <span class="detail-badge">
                <?= $isRent ? "CHO THUÊ" : "SẢN PHẨM BÁN" ?>
            </span>

            <h1><?= e($product["name"]) ?></h1>

            <div class="detail-price">
                <?= money($product["price"]) ?>

                <?php if ($isRent): ?>
                    <small>/ ngày</small>
                <?php endif; ?>
            </div>

            <p class="detail-description">
                <?= nl2br(e($product["description"] ?? "")) ?>
            </p>

            <p class="detail-stock">
                <?php if ($stock > 0): ?>
                    Còn hàng: <?= $stock ?> sản phẩm
                <?php else: ?>
                    <span style="color:red">
                        Sản phẩm hiện đã hết hàng
                    </span>
                <?php endif; ?>
            </p>

            <!-- FORM THEM VAO GIO HANG -->
            <?php if ($stock > 0): ?>

                <form
                    class="detail-form"
                    action="cart.php"
                    method="POST"
                    id="addCartForm"
                >

                    <!-- Ma bao mat cho form them gio hang -->
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                    <input
                        type="hidden"
                        name="action"
                        value="add"
                    >

                    <input
                        type="hidden"
                        name="product_id"
                        value="<?= (int)$product['id'] ?>"
                    >

                    <label for="quantity">
                        Số lượng
                    </label>

                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        value="1"
                        min="1"
                        max="<?= $stock ?>"
                        required
                    >

                    <?php if ($isRent): ?>

                        <div class="detail-dates">

                            <div>
                                <label for="start_date">
                                    Ngày bắt đầu thuê
                                </label>

                                <input
                                    type="date"
                                    id="start_date"
                                    name="start_date"
                                    min="<?= $today ?>"
                                    required
                                >
                            </div>

                            <div>
                                <label for="end_date">
                                    Ngày kết thúc thuê
                                </label>

                                <input
                                    type="date"
                                    id="end_date"
                                    name="end_date"
                                    min="<?= $today ?>"
                                    required
                                >
                            </div>

                        </div>

                        <p style="color:#777;font-size:13px">
                            Tiền thuê = Giá/ngày × Số ngày × Số lượng.
                            Ngày kết thúc phải sau ngày bắt đầu.
                        </p>

                    <?php endif; ?>

                    <p id="detail-total" style="font-weight:600;color:#263c2b;margin:10px 0;"></p>
                    <?php if ($isRent): ?>
                        <p id="rental-live" aria-live="polite" style="color:#666;font-size:13px;margin:10px 0;"></p>
                    <?php endif; ?>

                    <button
                        type="submit"
                        class="detail-add-btn"
                    >
                        <?= $isRent
                            ? "Thêm sản phẩm thuê vào giỏ"
                            : "Thêm vào giỏ hàng" ?>
                    </button>

                </form>

            <?php else: ?>

                <button class="detail-add-btn" disabled>
                    Tạm hết hàng
                </button>

            <?php endif; ?>

            <div class="detail-links">
                <a href="products.php">
                    ← Tiếp tục mua sắm
                </a>

                <a href="cart.php">
                    Xem giỏ hàng →
                </a>
            </div>

        </div>
    </div>
</main>

<script>
const startInput = document.getElementById('start_date');
const endInput = document.getElementById('end_date');
const qtyInput = document.getElementById('quantity');
const totalBox = document.getElementById('detail-total');
const availabilityBox = document.getElementById('rental-live');
const addBtn = document.querySelector('.detail-add-btn[type="submit"]');
const price = <?= json_encode((float)$product['price']) ?>;
const isRent = <?= $isRent ? 'true' : 'false' ?>;
let available = <?= (int)$stock ?>;
let requestNumber = 0;
function daysBetween(a,b){return Math.round((new Date(b+'T00:00:00')-new Date(a+'T00:00:00'))/86400000);}
async function updateRental(){
  const q = Math.max(1,Number(qtyInput?.value || 1));
  if (!isRent){totalBox.textContent='Tạm tính: '+(price*q).toLocaleString('vi-VN')+'đ';return;}
  const a=startInput.value,b=endInput.value;
  if (a) endInput.min=a;
  const days= a && b ? daysBetween(a,b) : 0;
  totalBox.textContent=days>0?'Tạm tính: '+(price*q*days).toLocaleString('vi-VN')+'đ ('+days+' ngày)':'';
  const req=++requestNumber;
  if(days<1 || a < <?= json_encode($today) ?>){availabilityBox.textContent='Chọn ngày trả sau ngày nhận (tối đa 365 ngày).';addBtn.disabled=true;return;}
  availabilityBox.textContent='Đang kiểm tra lịch thuê...';addBtn.disabled=true;
  try{
    const url='product_detail.php?id=<?= (int)$product['id'] ?>&check_availability=1&start_date='+encodeURIComponent(a)+'&end_date='+encodeURIComponent(b);
    const response=await fetch(url,{credentials:'same-origin'});
    if(!response.ok) throw Error('network');
    const data=await response.json();
    if(req!==requestNumber)return;
    available=Number(data.available);
    availabilityBox.textContent='Còn '+available+' sản phẩm trong khoảng ngày đã chọn.';
    addBtn.disabled=days>365 || available<q;
    if(available<q)availabilityBox.textContent+=' Vui lòng giảm số lượng hoặc đổi ngày.';
  }catch(e){if(req===requestNumber){availabilityBox.textContent='Không kiểm tra được lịch. Vui lòng thử lại.';addBtn.disabled=true;}}
}
[startInput,endInput,qtyInput].filter(Boolean).forEach(el=>el.addEventListener('change',updateRental));
if(qtyInput)qtyInput.addEventListener('input',updateRental);
document.getElementById('addCartForm')?.addEventListener('submit',function(e){
 if(isRent && (!startInput.value || !endInput.value || daysBetween(startInput.value,endInput.value)<1 || Number(qtyInput.value)>available)){
 e.preventDefault();alert('Ngày thuê hoặc số lượng không hợp lệ.');}
});
updateRental();
</script>

<?php include "footer.php"; ?>
