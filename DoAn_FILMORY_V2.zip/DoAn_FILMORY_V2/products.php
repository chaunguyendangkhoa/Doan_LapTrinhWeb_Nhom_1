
<?php
require_once __DIR__ . "/config/database.php";

// Ham chong XSS
function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

// Ham dinh dang tien VNĐ
function money($price) {
    return number_format(
        (float)$price,
        0,
        ",",
        "."
    ) . "đ";
}

// Lay bo loc tu URL
$type = $_GET["type"] ?? "all";

if (!in_array($type, ["all", "thue", "mua"], true)) {
    $type = "all";
}

$keyword = trim($_GET["q"] ?? "");

$cat_id = filter_var(
    $_GET["category"] ?? 0,
    FILTER_VALIDATE_INT
);

if ($cat_id === false || $cat_id < 0) {
    $cat_id = 0;
}

// Lay danh sach danh muc
$sqlCategory = "
    SELECT id, name
    FROM danhmucsanpham
    ORDER BY id ASC
";

$categories = $conn->query($sqlCategory);

// Xay dung cau truy van san pham
$sql = "
    SELECT
        sanpham.*,
        danhmucsanpham.name AS category_name
    FROM sanpham
    LEFT JOIN danhmucsanpham
        ON sanpham.DanhMucSanPham_id = danhmucsanpham.id
    WHERE 1 = 1
";

$types = "";
$params = [];

// Loc theo loai thue / mua
if ($type !== "all") {
    $sql .= " AND sanpham.product_type = ?";
    $types .= "s";
    $params[] = $type;
}

// Loc theo danh muc
if ($cat_id > 0) {
    $sql .= " AND sanpham.DanhMucSanPham_id = ?";
    $types .= "i";
    $params[] = $cat_id;
}

// Tim kiem theo ten
if ($keyword !== "") {
    $sql .= " AND sanpham.name LIKE ?";
    $types .= "s";
    $params[] = "%" . $keyword . "%";
}

// San pham moi nhat len dau
$sql .= " ORDER BY sanpham.id DESC";

// Prepared Statement
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Lỗi truy vấn sản phẩm: " . e($conn->error));
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();

$products = $stmt->get_result();
$totalProducts = $products->num_rows;

// Tao URL giu lai bo loc
function filterUrl($type, $cat_id, $keyword) {
    $query = [];

    if ($type !== "all") {
        $query["type"] = $type;
    }

    if ($cat_id > 0) {
        $query["category"] = $cat_id;
    }

    if ($keyword !== "") {
        $query["q"] = $keyword;
    }

    return "products.php" .
        ($query ? "?" . http_build_query($query) : "");
}
?>

<?php include "header.php"; ?>

<style>
.filmory-filter-form {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
    margin-top: 18px;
    margin-bottom: 25px;
}

.filmory-filter-form input,
.filmory-filter-form select {
    padding: 11px 14px;
    border: 1px solid #d8ddd5;
    border-radius: 8px;
    background: #fff;
    font-size: 14px;
}

.filmory-filter-form input {
    min-width: 220px;
}

.filmory-filter-form button {
    padding: 11px 20px;
    border: none;
    border-radius: 8px;
    background: #263c2b;
    color: white;
    cursor: pointer;
}

.filmory-filter-form button:hover {
    background: #17291c;
}

.filmory-reset {
    color: #315b40;
    text-decoration: none;
}

.filmory-empty {
    grid-column: 1 / -1;
    text-align: center;
    padding: 55px 20px;
    background: #f6f7f4;
    border-radius: 12px;
}

.filmory-empty a {
    color: #315b40;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.product-button[disabled] {
    opacity: .5;
    cursor: not-allowed;
}

@media (max-width: 768px) {
    .filmory-filter-form {
        align-items: stretch;
        flex-direction: column;
    }

    .filmory-filter-form input,
    .filmory-filter-form select,
    .filmory-filter-form button {
        width: 100%;
        box-sizing: border-box;
    }
}
</style>

<main class="products-page">

    <!-- TIEU DE -->
    <section class="products-heading">
        <p class="eyebrow">
            FILMORY CAMERA STORE
        </p>

        <h1>
            Thiết bị dành cho người yêu nhiếp ảnh
        </h1>

        <p>
            Khám phá máy ảnh, ống kính và phụ kiện
            phục vụ mọi hành trình sáng tạo.
        </p>
    </section>

    <section class="products-container">

        <!-- THANH LOC -->
        <div class="products-toolbar">

            <div>
                <h2>Sản phẩm của chúng tôi</h2>
                <p>
                    <?= $totalProducts ?> sản phẩm
                </p>
            </div>

            <div class="product-filters">

                <a
                    href="<?= e(filterUrl("all", $cat_id, $keyword)) ?>"
                    class="<?= $type === "all" ? "active" : "" ?>"
                >
                    Tất cả
                </a>

                <a
                    href="<?= e(filterUrl("thue", $cat_id, $keyword)) ?>"
                    class="<?= $type === "thue" ? "active" : "" ?>"
                >
                    Cho thuê
                </a>

                <a
                    href="<?= e(filterUrl("mua", $cat_id, $keyword)) ?>"
                    class="<?= $type === "mua" ? "active" : "" ?>"
                >
                    Mua sản phẩm
                </a>

            </div>
        </div>

        <!-- TIM KIEM VA LOC DANH MUC -->
        <form
            class="filmory-filter-form"
            method="GET"
            action="products.php"
        >

            <input
                type="hidden"
                name="type"
                value="<?= e($type) ?>"
            >

            <input
                type="text"
                name="q"
                value="<?= e($keyword) ?>"
                placeholder="Tìm kiếm sản phẩm..."
            >

            <select name="category">
                <option value="0">
                    Tất cả danh mục
                </option>

                <?php while ($category = $categories->fetch_assoc()): ?>

                    <option
                        value="<?= (int)$category["id"] ?>"
                        <?= $cat_id === (int)$category["id"]
                            ? "selected" : "" ?>
                    >
                        <?= e($category["name"]) ?>
                    </option>

                <?php endwhile; ?>
            </select>

            <button type="submit">
                Tìm kiếm
            </button>

            <a
                class="filmory-reset"
                href="products.php"
            >
                Xóa bộ lọc
            </a>

        </form>

        <!-- DANH SACH SAN PHAM -->
        <div class="product-grid">

            <?php if ($totalProducts > 0): ?>

                <?php while ($product = $products->fetch_assoc()): ?>

                    <article class="product-card">

                        <!-- ANH SAN PHAM -->
                        <div class="product-image">

                            <?php if (!empty($product["image"])): ?>

                                <img
                                    src="assets/images/<?= e($product['image']) ?>"
                                    alt="<?= e($product['name']) ?>"
                                    loading="lazy"
                                    onerror="this.style.display='none'"
                                >

                            <?php else: ?>

                                <div class="no-image">
                                    FILMORY
                                </div>

                            <?php endif; ?>

                            <span class="product-badge">
                                <?= $product["product_type"] === "thue"
                                    ? "Cho thuê"
                                    : "Bán" ?>
                            </span>

                        </div>

                        <!-- THONG TIN SAN PHAM -->
                        <div class="product-info">

                            <p class="product-category">
                                <?= e(
                                    $product["category_name"]
                                    ?? "Chưa phân loại"
                                ) ?>
                            </p>

                            <h3>
                                <?= e($product["name"]) ?>
                            </h3>

                            <p class="product-description">
                                <?= e($product["description"] ?? "") ?>
                            </p>

                            <div class="product-bottom">

                                <div class="product-price">

                                    <strong>
                                        <?= money($product["price"]) ?>
                                    </strong>

                                    <?php if (
                                        $product["product_type"] === "thue"
                                    ): ?>
                                        <span>/ ngày</span>
                                    <?php endif; ?>

                                </div>

                                <span class="product-stock">
                                    <?php if ((int)$product["stock"] > 0): ?>

                                        Còn hàng
                                        (<?= (int)$product["stock"] ?>)

                                    <?php else: ?>

                                        Hết hàng

                                    <?php endif; ?>
                                </span>

                            </div>

                            <!-- NUT XEM CHI TIET -->
                            <?php if ((int)$product["stock"] > 0): ?>

                                <a
                                    class="product-button"
                                    href="product_detail.php?id=<?= (int)$product['id'] ?>"
                                >
                                    Xem chi tiết
                                </a>

                            <?php else: ?>

                                <button
                                    class="product-button"
                                    disabled
                                >
                                    Tạm hết hàng
                                </button>

                            <?php endif; ?>

                        </div>
                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="filmory-empty">
                    <h3>Không tìm thấy sản phẩm</h3>

                    <p>
                        Hãy thử từ khóa hoặc danh mục khác.
                    </p>

                    <a href="products.php">
                        Xem tất cả sản phẩm
                    </a>
                </div>

            <?php endif; ?>

        </div>

    </section>

</main>

<?php
$stmt->close();
include "footer.php";
?>
