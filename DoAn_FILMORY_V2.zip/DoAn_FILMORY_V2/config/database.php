<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "doan";
$port = 3307; // Doi neu MySQL cua ban chay cong khac
try {
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    error_log($e->getMessage());
    die("Không thể kết nối cơ sở dữ liệu. Vui lòng kiểm tra MySQL và cấu hình.");
}
