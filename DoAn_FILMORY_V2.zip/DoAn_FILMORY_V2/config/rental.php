<?php
// Helper chung: ngay tra la moc ket thuc, khong tinh them ngay tra.
function rental_days_valid($start, $end) {
    if (!is_string($start) || !is_string($end)) return 0;
    $a = DateTimeImmutable::createFromFormat('!Y-m-d', $start);
    $b = DateTimeImmutable::createFromFormat('!Y-m-d', $end);
    if (!$a || !$b || $a->format('Y-m-d') !== $start || $b->format('Y-m-d') !== $end || $b <= $a) return 0;
    return (int)$a->diff($b)->days;
}
function rental_available($conn, $productId, $start, $end, $stock, $cart = [], $excludeKey = null) {
    $days = rental_days_valid($start, $end);
    if ($days < 1 || $start < date('Y-m-d') || $stock < 1 || $days > 365) return 0;
    $used = array_fill(0, $days, 0);
    $stmt = $conn->prepare("SELECT ct.quantity, ct.start_date, ct.end_date FROM chitietdonhang ct JOIN donhang dh ON dh.id = ct.DonHang_id WHERE ct.SanPham_id = ? AND ct.start_date < ? AND ct.end_date > ? AND dh.status <> 'cancelled'");
    $stmt->bind_param('iss', $productId, $end, $start);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    foreach ($cart as $key => $entry) {
        if ($key === $excludeKey || !is_array($entry) || (int)($entry['product_id'] ?? 0) !== $productId) continue;
        if (empty($entry['start_date']) || empty($entry['end_date'])) continue;
        $rows[] = ['quantity' => (int)($entry['quantity'] ?? 0), 'start_date' => $entry['start_date'], 'end_date' => $entry['end_date']];
    }
    $base = new DateTimeImmutable($start);
    foreach ($rows as $row) {
        for ($i=0; $i<$days; $i++) {
            $day = $base->modify('+' . $i . ' days')->format('Y-m-d');
            if ($row['start_date'] <= $day && $row['end_date'] > $day) $used[$i] += (int)$row['quantity'];
        }
    }
    return max(0, $stock - max($used));
}
