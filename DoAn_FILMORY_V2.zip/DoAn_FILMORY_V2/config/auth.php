<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
function auth_e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function auth_logged_in() {
    return isset($_SESSION['user_id']);
}
function auth_csrf_valid() {
    return isset($_POST['csrf_token']) && is_string($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}
