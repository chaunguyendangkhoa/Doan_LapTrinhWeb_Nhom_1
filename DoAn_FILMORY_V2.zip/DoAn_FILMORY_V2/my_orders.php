<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';

if (!auth_logged_in()) {
    header('Location: login.php');
    exit;
}

$userId = (int)$_SESSION['user_id'];
function customer_money($n) {
    return number_format((float)$n, 0, ',', '.') . 'đ';
}

// Chi hien thi don hang cua tai khoan dang dang nhap.
$stmt = $conn->prepare('SELECT id, customer_name, total_amount, status, order_date FROM donhang WHERE NguoiDung_id = ? ORDER BY id DESC');
$stmt->bind_param('i', $userId);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$detailsByOrder = [];
if ($orders) {
    $ids = array_map('intval', array_column($orders, 'id'));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $sql = "SELECT ct.DonHang_id, ct.quantity, ct.price, ct.start_date, ct.end_date, s.name, s.product_type
            FROM chitietdonhang ct
            LEFT JOIN sanpham s ON s.id = ct.SanPham_id
            WHERE ct.DonHang_id IN ($placeholders)
            ORDER BY ct.id ASC";
    $detailStmt = $conn->prepare($sql);
    $detailStmt->bind_param($types, ...$ids);
    $detailStmt->execute();
    $detailRows = $detailStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $detailStmt->close();
    foreach ($detailRows as $row) {
        $detailsByOrder[(int)$row['DonHang_id']][] = $row;
    }
}

$labels = [
    'pending' => 'Chờ xử lý',
    'processing' => 'Đang xử lý',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy'
];

include __DIR__ . '/header.php';
?>
<link rel="stylesheet" href="assets/css/customer.css">
<style>
/* Chi ap dung cho trang Don hang cua toi, khong anh huong CSS chung. */
.filmory-orders {max-width:1120px;margin:48px auto 80px;padding:0 20px;color:#4b3024}
.filmory-orders h1 {margin:0 0 12px;font-size:clamp(28px,3vw,38px)}
.filmory-orders .intro {color:#846b59;margin-bottom:26px}
.filmory-order {background:#fffaf1;border:1px solid #e4cdb0;border-radius:14px;margin-bottom:22px;overflow:hidden;box-shadow:0 8px 24px rgba(72,39,20,.05)}
.filmory-order-head {display:flex;justify-content:space-between;gap:15px;align-items:center;flex-wrap:wrap;padding:20px 24px;background:#f6e8d1;border-bottom:1px solid #e4cdb0}
.filmory-order-head strong {font-size:20px}
.filmory-order-date {display:block;color:#826956;font-size:13px;margin-top:5px}
.filmory-order-status {border-radius:999px;padding:7px 13px;background:#eee0c8;color:#68432f;font-size:13px;font-weight:700}
.filmory-order-status.completed {background:#e2efdf;color:#2b6536}
.filmory-order-status.cancelled {background:#f6e0de;color:#94382f}
.filmory-order-status.processing {background:#e2eafa;color:#315a8e}
.filmory-order-items {padding:8px 24px}
.filmory-order-item {padding:15px 0;border-bottom:1px solid #ecdfcd;display:flex;justify-content:space-between;gap:15px;align-items:start}
.filmory-order-item:last-child {border-bottom:0}
.filmory-order-item b {display:block;margin-bottom:5px}
.filmory-order-item small {display:block;color:#866c59;line-height:1.8}
.filmory-order-price {white-space:nowrap;font-weight:700}
.filmory-order-bottom {display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;padding:18px 24px;border-top:1px solid #e4cdb0}
.filmory-order-total {font-size:19px;font-weight:700;color:#8c3025}
.filmory-order-link,.filmory-empty a {display:inline-block;background:#74452e;color:#fff!important;text-decoration:none;padding:11px 18px;border-radius:7px}
.filmory-order-link:hover,.filmory-empty a:hover {background:#542e1e}
.filmory-empty {background:#fffaf1;border:1px solid #e4cdb0;border-radius:12px;padding:28px}
.filmory-empty p {margin:0 0 14px}
@media(max-width:600px){.filmory-order-item{flex-direction:column}.filmory-order-head,.filmory-order-items,.filmory-order-bottom{padding-left:16px;padding-right:16px}}
</style>
<main class="filmory-orders">
    <h1>Đơn hàng của tôi</h1>
    <p class="intro">Theo dõi các sản phẩm đã mua và thiết bị đã thuê tại FILMORY.</p>

    <?php if (!$orders): ?>
        <section class="filmory-empty">
            <p>Bạn chưa có đơn hàng liên kết với tài khoản này.</p>
            <p>Đơn hàng cũ chưa được gắn tài khoản vẫn được lưu trong hệ thống.</p>
            <a href="products.php">Khám phá sản phẩm</a>
        </section>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
            <?php $orderId = (int)$order['id']; $status = (string)$order['status']; ?>
            <article class="filmory-order">
                <div class="filmory-order-head">
                    <div>
                        <strong>Đơn hàng #<?= $orderId ?></strong>
                        <span class="filmory-order-date">Ngày đặt: <?= auth_e($order['order_date']) ?> · <?= auth_e($order['customer_name']) ?></span>
                    </div>
                    <span class="filmory-order-status <?= auth_e($status) ?>"><?= auth_e($labels[$status] ?? $status) ?></span>
                </div>
                <div class="filmory-order-items">
                    <?php foreach ($detailsByOrder[$orderId] ?? [] as $item): ?>
                        <div class="filmory-order-item">
                            <div>
                                <b><?= auth_e($item['name'] ?? 'Sản phẩm đã xóa') ?></b>
                                <small><?= $item['product_type'] === 'thue' ? 'Cho thuê' : 'Mua sản phẩm' ?> · Số lượng: <?= (int)$item['quantity'] ?></small>
                                <?php if ($item['product_type'] === 'thue'): ?>
                                    <small>Thời gian thuê: <?= auth_e($item['start_date'] ?? '—') ?> đến <?= auth_e($item['end_date'] ?? '—') ?></small>
                                <?php endif; ?>
                            </div>
                            <span class="filmory-order-price"><?= customer_money($item['price']) ?><?= $item['product_type'] === 'thue' ? ' / ngày' : '' ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="filmory-order-bottom">
                    <div>Tổng đơn hàng: <span class="filmory-order-total"><?= customer_money($order['total_amount']) ?></span></div>
                    <a class="filmory-order-link" href="my_order_detail.php?id=<?= $orderId ?>">Xem chi tiết →</a>
                </div>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>
</main>
<?php include __DIR__ . '/footer.php'; ?>
