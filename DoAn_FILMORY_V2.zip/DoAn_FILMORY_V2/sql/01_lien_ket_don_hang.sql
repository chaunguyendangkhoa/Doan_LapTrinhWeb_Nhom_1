-- Chay MOT LAN trong database doan, sau khi sao luu.
-- Khong xoa du lieu don hang cu. Don cu se co NguoiDung_id = NULL.
ALTER TABLE donhang
  ADD COLUMN NguoiDung_id INT NULL DEFAULT NULL AFTER id,
  ADD INDEX idx_donhang_nguoidung (NguoiDung_id),
  ADD CONSTRAINT fk_donhang_nguoidung FOREIGN KEY (NguoiDung_id)
    REFERENCES nguoidung(id) ON DELETE SET NULL ON UPDATE CASCADE;
