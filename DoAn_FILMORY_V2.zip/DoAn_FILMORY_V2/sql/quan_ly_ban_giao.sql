-- Chạy một lần trong database doan. Không sửa/xóa đơn hàng cũ.
CREATE TABLE IF NOT EXISTS ban_giao_thue (
 id INT AUTO_INCREMENT PRIMARY KEY,
 ChiTietDonHang_id INT NOT NULL UNIQUE,
 trang_thai ENUM('cho_nhan','da_giao','da_tra') NOT NULL DEFAULT 'cho_nhan',
 ngay_giao DATETIME NULL,
 ngay_tra DATETIME NULL,
 ghi_chu VARCHAR(500) NULL,
 cap_nhat_luc TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_bangiao_chitiet FOREIGN KEY (ChiTietDonHang_id)
 REFERENCES chitietdonhang(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
