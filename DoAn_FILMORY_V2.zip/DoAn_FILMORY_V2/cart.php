
<?php
require_once __DIR__ . "/config/auth.php";
require_once __DIR__ . "/config/rental.php";
require_once __DIR__ . "/config/database.php";

// Khoi tao gio hang
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Ham chong XSS
function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

// Ham dinh dang tien
function money($price) {
    return number_format(
        (float)$price, 0, ",", "."
    ) . "đ";
}

// Ham kiem tra ngay thue
function rentalDays($startDate, $endDate) {
    if (!is_string($startDate) || !is_string($endDate)) {
        return 0;
    }

    $start = DateTimeImmutable::createFromFormat(
        "!Y-m-d", $startDate
    );
    $end = DateTimeImmutable::createFromFormat(
        "!Y-m-d", $endDate
    );

    if (
        !$start || !$end ||
        $start->format("Y-m-d") !== $startDate ||
        $end->format("Y-m-d") !== $endDate ||
        $end <= $start
    ) {
        return 0;
    }

    return (int)$start->diff($end)->days;
}

$error = "";

// XU LY FORM
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!auth_csrf_valid()) {
        http_response_code(403);
        die('Phiên biểu mẫu không hợp lệ. Vui lòng tải lại trang.');
    }
    $action = $_POST["action"] ?? "";

    // THEM SAN PHAM
    if ($action === "add") {
        $id = filter_var(
            $_POST["product_id"] ?? null,
            FILTER_VALIDATE_INT
        );

        $quantity = filter_var(
            $_POST["quantity"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (!$id || !$quantity || $quantity < 1) {
            $error = "Mã sản phẩm hoặc số lượng không hợp lệ!";
        } else {
            // Lay san pham tu MySQL
            $stmt = $conn->prepare(
                "SELECT * FROM sanpham WHERE id = ?"
            );
            $stmt->bind_param("i", $id);
            $stmt->execute();

            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$product) {
                $error = "Sản phẩm không tồn tại!";
            } elseif ($quantity > (int)$product["stock"]) {
                $error = "Số lượng vượt quá tồn kho!";
            } else {
                $startDate = null;
                $endDate = null;

                // Neu la san pham thue
                if ($product["product_type"] === "thue") {
                    $startDate = $_POST["start_date"] ?? "";
                    $endDate = $_POST["end_date"] ?? "";

                    if (
                        rentalDays($startDate, $endDate) < 1 ||
                        $startDate < date("Y-m-d")
                    ) {
                        $error = "Ngày thuê không hợp lệ!";
                    }
                }

                if ($error === "") {
                    // Moi khoang ngay thue la mot dong rieng
                    $key = $id . "_" .
                        ($startDate ?? "mua") . "_" .
                        ($endDate ?? "mua");

                    $oldQuantity = (int)(
                        $_SESSION["cart"][$key]["quantity"] ?? 0
                    );

                    $available = $product["product_type"] === "thue"
                        ? rental_available($conn, $id, $startDate, $endDate, (int)$product["stock"], $_SESSION["cart"], $key)
                        : (int)$product["stock"];
                    if ($oldQuantity + $quantity > $available) {
                        $error = "Không đủ số lượng tồn kho!";
                    } else {
                        $_SESSION["cart"][$key] = [
                            "product_id" => $id,
                            "quantity" => $oldQuantity + $quantity,
                            "start_date" => $startDate,
                            "end_date" => $endDate
                        ];

                        header("Location: cart.php");
                        exit;
                    }
                }
            }
        }
    }

    // CAP NHAT SO LUONG
    elseif ($action === "update") {
        $key = $_POST["key"] ?? "";

        $quantity = filter_var(
            $_POST["quantity"] ?? null,
            FILTER_VALIDATE_INT
        );

        if (
            !isset($_SESSION["cart"][$key]) ||
            !$quantity || $quantity < 1
        ) {
            $error = "Số lượng không hợp lệ!";
        } else {
            $id = (int)$_SESSION["cart"][$key]["product_id"];

            $stmt = $conn->prepare(
                "SELECT stock FROM sanpham WHERE id = ?"
            );
            $stmt->bind_param("i", $id);
            $stmt->execute();

            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$product) {
                $error = "Sản phẩm không tồn tại!";
            } else {
                $entry = $_SESSION["cart"][$key];
                $newStart = $entry['start_date'] ?? null;
                $newEnd = $entry['end_date'] ?? null;
                $typeStmt = $conn->prepare('SELECT product_type FROM sanpham WHERE id = ?');
                $typeStmt->bind_param('i', $id);
                $typeStmt->execute();
                $type = $typeStmt->get_result()->fetch_assoc()['product_type'] ?? '';
                $typeStmt->close();
                if ($type === 'thue') {
                    $newStart = (string)($_POST['start_date'] ?? $newStart);
                    $newEnd = (string)($_POST['end_date'] ?? $newEnd);
                }
                $available = $type === 'thue'
                    ? rental_available($conn, $id, $newStart, $newEnd, (int)$product['stock'], $_SESSION['cart'], $key)
                    : (int)$product['stock'];
                if ($quantity > $available || ($type === 'thue' && rental_days_valid($newStart, $newEnd) < 1)) {
                    $error = 'Không đủ số lượng trống hoặc ngày thuê không hợp lệ!';
                } else {
                unset($_SESSION['cart'][$key]);
                $newKey = $id . '_' . ($newStart ?? 'mua') . '_' . ($newEnd ?? 'mua');
                $existing = (int)($_SESSION['cart'][$newKey]['quantity'] ?? 0);
                if ($existing + $quantity > $available) {
                    $error = 'Số lượng vượt quá lịch còn trống!';
                    $_SESSION['cart'][$key] = $entry;
                } else {
                $_SESSION['cart'][$newKey] = ['product_id'=>$id, 'quantity'=>$quantity+$existing, 'start_date'=>$newStart, 'end_date'=>$newEnd];
                header("Location: cart.php"); exit;
                }
                }
            }
        }
    }

    // XOA SAN PHAM
    elseif ($action === "remove") {
        $key = $_POST["key"] ?? "";

        if (isset($_SESSION["cart"][$key])) {
            unset($_SESSION["cart"][$key]);
        }

        header("Location: cart.php");
        exit;
    }

    // XOA TOAN BO GIO HANG
    elseif ($action === "clear") {
        $_SESSION["cart"] = [];

        header("Location: cart.php");
        exit;
    }
}

// LAY DU LIEU GIO HANG
$items = [];
$total = 0;
$cartValid = true;

foreach ($_SESSION["cart"] as $key => $cartItem) {
    if (
        !is_array($cartItem) ||
        !isset($cartItem["product_id"], $cartItem["quantity"])
    ) {
        $cartValid = false;
        continue;
    }

    $id = (int)$cartItem["product_id"];
    $quantity = (int)$cartItem["quantity"];

    $stmt = $conn->prepare(
        "SELECT * FROM sanpham WHERE id = ?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (
        !$product ||
        $quantity < 1 ||
        $quantity > (int)$product["stock"]
    ) {
        $cartValid = false;
        continue;
    }

    $price = (float)$product["price"];
    $days = 1;

    if ($product["product_type"] === "thue") {
        $days = rentalDays(
            $cartItem["start_date"] ?? null,
            $cartItem["end_date"] ?? null
        );

        if (
            $days < 1 ||
            ($cartItem["start_date"] ?? "") < date("Y-m-d")
        ) {
            $cartValid = false;
            continue;
        }
    }

    if ($product['product_type'] === 'thue') {
        $available = rental_available($conn, $id, $cartItem['start_date'], $cartItem['end_date'], (int)$product['stock'], $_SESSION['cart'], $key);
        if ($quantity > $available) $cartValid = false;
    }
    // Tinh tien mua hoac thue
    $subtotal = $price * $quantity * $days;
    $total += $subtotal;

    $items[] = [
        "key" => $key,
        "product" => $product,
        "quantity" => $quantity,
        "days" => $days,
        "subtotal" => $subtotal,
        "start_date" => $cartItem["start_date"] ?? null,
        "end_date" => $cartItem["end_date"] ?? null
    ];
}
?>

<?php include "header.php"; ?>

<style>
.cart-page {
    max-width: 1200px;
    margin: 50px auto;
    padding: 20px;
}

.cart-page h1 {
    font-size: 34px;
    margin-bottom: 30px;
}

.cart-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
}

.cart-table th,
.cart-table td {
    padding: 18px;
    border-bottom: 1px solid #eee;
    text-align: left;
    vertical-align: middle;
}

.cart-table th {
    background: #f4f6f2;
    color: #333;
}

.cart-product {
    display: flex;
    align-items: center;
    gap: 15px;
}

.cart-product img {
    width: 85px;
    height: 85px;
    object-fit: cover;
    border-radius: 8px;
}

.cart-quantity {
    width: 65px;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

.cart-btn {
    padding: 9px 14px;
    background: #263c2b;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.cart-btn:hover {
    background: #17291c;
}

.cart-remove {
    background: #b43b3b;
}

.cart-summary {
    margin-top: 30px;
    text-align: right;
}

.cart-total {
    font-size: 26px;
    font-weight: bold;
    color: #263c2b;
    margin-bottom: 25px;
}

.checkout-btn {
    display: inline-block;
    background: #263c2b;
    color: white;
    padding: 15px 30px;
    border-radius: 8px;
    text-decoration: none;
}

.cart-empty {
    padding: 60px 20px;
    text-align: center;
    background: #f7f8f5;
    border-radius: 12px;
}

.cart-alert {
    background: #fff0f0;
    color: #a22222;
    padding: 14px;
    border-radius: 8px;
    margin-bottom: 20px;
}

@media (max-width: 768px) {
    .cart-table {
        display: block;
        overflow-x: auto;
    }

    .cart-page h1 {
        font-size: 27px;
    }
}
</style>

<main class="cart-page">

    <h1>Giỏ hàng của bạn</h1>

    <?php if ($error): ?>
        <div class="cart-alert">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <?php if (!$cartValid): ?>
        <div class="cart-alert">
            Một số sản phẩm trong giỏ hàng không hợp lệ,
            đã hết hàng hoặc có ngày thuê không hợp lệ.
            Vui lòng kiểm tra và xóa các sản phẩm đó.
        </div>
    <?php endif; ?>

    <?php if (empty($items)): ?>

        <div class="cart-empty">
            <h2>Giỏ hàng đang trống</h2>
            <p>Bạn chưa có sản phẩm hợp lệ trong giỏ hàng.</p>

            <a href="products.php" class="checkout-btn">
                Khám phá sản phẩm
            </a>
        </div>

    <?php else: ?>

        <table class="cart-table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Đơn giá</th>
                    <th>Số lượng</th>
                    <th>Ngày thuê</th>
                    <th>Thành tiền</th>
                    <th>Thao tác</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($items as $item): ?>
                    <?php $product = $item["product"]; ?>

                    <tr>
                        <td>
                            <div class="cart-product">

                                <?php if (!empty($product["image"])): ?>
                                    <img
                                        src="assets/images/<?= e($product['image']) ?>"
                                        alt="<?= e($product['name']) ?>"
                                    >
                                <?php endif; ?>

                                <div>
                                    <strong>
                                        <?= e($product["name"]) ?>
                                    </strong>

                                    <p>
                                        <?= $product["product_type"] === "thue"
                                            ? "Cho thuê" : "Mua" ?>
                                    </p>
                                </div>

                            </div>
                        </td>

                        <td>
                            <?= money($product["price"]) ?>

                            <?php if ($product["product_type"] === "thue"): ?>
                                <small>/ ngày</small>
                            <?php endif; ?>
                        </td>

                        <td>
                            <form method="POST"><input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                <input
                                    type="hidden"
                                    name="action"
                                    value="update"
                                >

                                <input
                                    type="hidden"
                                    name="key"
                                    value="<?= e($item['key']) ?>"
                                >

                                <input
                                    class="cart-quantity"
                                    type="number"
                                    name="quantity"
                                    min="1"
                                    max="<?= (int)$product['stock'] ?>"
                                    value="<?= $item['quantity'] ?>"
                                    required
                                >

                                <button class="cart-btn" type="submit">
                                    Cập nhật
                                </button>
                            </form>
                        </td>

                        <td>
                            <?php if ($product["product_type"] === "thue"): ?>

                                <p>
                                    Từ:
                                    <?= e($item["start_date"]) ?>
                                </p>

                                <p>
                                    Đến:
                                    <?= e($item["end_date"]) ?>
                                </p>

                                <strong>
                                    <?= $item["days"] ?> ngày
                                </strong>

                            <?php else: ?>
                                Không áp dụng
                            <?php endif; ?>
                        </td>

                        <td>
                            <strong>
                                <?= money($item["subtotal"]) ?>
                            </strong>
                        </td>

                        <td>
                            <form method="POST"><input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                <input
                                    type="hidden"
                                    name="action"
                                    value="remove"
                                >

                                <input
                                    type="hidden"
                                    name="key"
                                    value="<?= e($item['key']) ?>"
                                >

                                <button
                                    class="cart-btn cart-remove"
                                    type="submit"
                                >
                                    Xóa
                                </button>
                            </form>
                        </td>
                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="cart-summary">

            <p class="cart-total">
                Tổng tiền: <?= money($total) ?>
            </p>

            <a href="products.php" style="margin-right:20px">
                ← Tiếp tục mua sắm
            </a>

            <?php if ($cartValid): ?>
                <a href="checkout.php" class="checkout-btn">
                    Tiến hành thanh toán →
                </a>
            <?php endif; ?>

            <form method="POST" style="margin-top:20px">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                <input type="hidden" name="action" value="clear">

                <button
                    class="cart-btn cart-remove"
                    type="submit"
                    onclick="return confirm('Xóa toàn bộ giỏ hàng?')"
                >
                    Xóa toàn bộ giỏ hàng
                </button>
            </form>

        </div>

    <?php endif; ?>

</main>

<?php include "footer.php"; ?>
