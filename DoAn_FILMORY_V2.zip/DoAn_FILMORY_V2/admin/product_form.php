<?php
require __DIR__.'/_init.php';
$id=positive_id($_GET['id']??($_POST['id']??0));
$product=['name'=>'','description'=>'','price'=>'','product_type'=>'thue','stock'=>0,'DanhMucSanPham_id'=>'','image'=>''];
if($id){$st=$conn->prepare('SELECT * FROM sanpham WHERE id=?');$st->bind_param('i',$id);$st->execute();$row=$st->get_result()->fetch_assoc();$st->close();if(!$row){http_response_code(404);exit('Không tìm thấy sản phẩm');}$product=$row;}
$categories=$conn->query('SELECT id,name FROM danhmucsanpham ORDER BY name')->fetch_all(MYSQLI_ASSOC);
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 foreach(['name','description','price','product_type','stock','DanhMucSanPham_id'] as $key){$product[$key]=trim((string)($_POST[$key]??''));}
 $price=filter_var($product['price'],FILTER_VALIDATE_INT,['options'=>['min_range'=>0]]);
 $stock=filter_var($product['stock'],FILTER_VALIDATE_INT,['options'=>['min_range'=>0]]);
 $cat=positive_id($product['DanhMucSanPham_id']);
 $categoryIds=array_map(fn($x)=>(int)$x['id'],$categories);
 if($product['name']==='' || mb_strlen($product['name'])>255 || mb_strlen($product['description'])>6000){$error='Tên hoặc mô tả không hợp lệ.';}
 elseif($price===false || $price>2147483647 || $stock===false || $stock>2147483647){$error='Giá hoặc số lượng không hợp lệ.';}
 elseif(!in_array($product['product_type'],['thue','mua'],true)){$error='Loại sản phẩm không hợp lệ.';}
 elseif(!in_array($cat,$categoryIds,true)){$error='Vui lòng chọn danh mục hợp lệ.';}
 $image=$product['image'];
 if($error==='' && isset($_FILES['image']) && $_FILES['image']['error']!==UPLOAD_ERR_NO_FILE){
  $f=$_FILES['image'];
  if($f['error']!==UPLOAD_ERR_OK || $f['size']>5*1024*1024 || $f['size']<1){$error='Ảnh phải nhỏ hơn 5MB và tải lên thành công.';}
  elseif(!is_uploaded_file($f['tmp_name'])){$error='Tệp tải lên không hợp lệ.';}
  else{
   $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
   $types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
   if(!isset($types[$mime]) || @getimagesize($f['tmp_name'])===false){$error='Chỉ chấp nhận ảnh JPG, PNG, WEBP.';}
   else{
    $dir=__DIR__.'/../assets/images';if(!is_dir($dir) && !mkdir($dir,0755,true)){$error='Không thể tạo thư mục ảnh.';}
    else{$filename='filmory_'.bin2hex(random_bytes(12)).'.'.$types[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$filename)){$error='Không thể lưu ảnh.';}else{$image=$filename;}}
   }
  }
 }
 if($error===''){
  try{
   $name=$product['name'];$description=$product['description'];$type=$product['product_type'];
   if($id){$st=$conn->prepare('UPDATE sanpham SET DanhMucSanPham_id=?,name=?,description=?,price=?,product_type=?,image=?,stock=? WHERE id=?');$st->bind_param('ississii',$cat,$name,$description,$price,$type,$image,$stock,$id);}
   else{$st=$conn->prepare('INSERT INTO sanpham (DanhMucSanPham_id,name,description,price,product_type,image,stock) VALUES (?,?,?,?,?,?,?)');$st->bind_param('ississi',$cat,$name,$description,$price,$type,$image,$stock);}
   $st->execute();$st->close();go('products.php','Đã lưu sản phẩm thành công.');
  }catch(Throwable $e){error_log('FILMORY admin product: '.$e->getMessage());$error='Không thể lưu sản phẩm.';}
 }
 $product['image']=$image;
}
admin_head($id?'Sửa sản phẩm':'Thêm sản phẩm','products.php'); ?>
<?php if($error):?><div class="error"><?=h($error)?></div><?php endif;?>
<section class="panel form-panel"><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['csrf_token'])?>"><input type="hidden" name="id" value="<?=$id?>">
<label>Tên sản phẩm *</label><input name="name" required maxlength="255" value="<?=h($product['name'])?>">
<label>Danh mục *</label><select name="DanhMucSanPham_id" required><option value="">Chọn danh mục</option><?php foreach($categories as $c):?><option value="<?=$c['id']?>" <?=((int)$product['DanhMucSanPham_id']===(int)$c['id'])?'selected':''?>><?=h($c['name'])?></option><?php endforeach;?></select>
<label>Mô tả</label><textarea name="description" rows="5"><?=h($product['description'])?></textarea>
<div class="two"><div><label>Giá (VNĐ) *</label><input type="number" name="price" min="0" max="2147483647" required value="<?=h($product['price'])?>"></div><div><label>Tồn kho *</label><input type="number" name="stock" min="0" max="2147483647" required value="<?=h($product['stock'])?>"></div></div>
<label>Loại sản phẩm *</label><select name="product_type"><option value="thue" <?=$product['product_type']==='thue'?'selected':''?>>Cho thuê (giá/ngày)</option><option value="mua" <?=$product['product_type']==='mua'?'selected':''?>>Bán</option></select>
<label>Hình ảnh (JPG / PNG / WEBP, tối đa 5MB)</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp"><p class="hint">Để trống nếu muốn giữ ảnh cũ.</p>
<?php if($product['image']):?><p class="hint">Ảnh hiện tại: <?=h($product['image'])?></p><?php endif;?>
<div class="actions"><button class="btn" type="submit">Lưu sản phẩm</button><a href="products.php">Hủy</a></div></form></section><?php admin_foot(); ?>
