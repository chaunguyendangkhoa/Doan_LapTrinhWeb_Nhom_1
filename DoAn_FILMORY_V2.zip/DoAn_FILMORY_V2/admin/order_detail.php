<?php
require __DIR__ . '/_init.php';

$id = positive_id($_GET['id'] ?? ($_POST['id'] ?? 0));
if (!$id) {
    http_response_code(400);
    exit('ID không hợp lệ');
}

$error = '';
$statuses = ['pending', 'processing', 'completed', 'cancelled'];
$statusLabels = [
    'pending' => 'Chờ xác nhận',
    'processing' => 'Đang xử lý',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy'
];
$rentalLabels = [
    'cho_nhan' => 'Chờ nhận',
    'da_giao' => 'Đã giao',
    'da_tra' => 'Đã trả'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $new = (string)($_POST['status'] ?? '');

    if (!in_array($new, $statuses, true)) {
        $error = 'Trạng thái không hợp lệ.';
    } else {
        try {
            $conn->begin_transaction();

            $st = $conn->prepare('SELECT status FROM donhang WHERE id = ? FOR UPDATE');
            $st->bind_param('i', $id);
            $st->execute();
            $old = $st->get_result()->fetch_assoc();
            $st->close();

            if (!$old) {
                throw new Exception('Không tìm thấy đơn hàng.');
            }

            $oldStatus = $old['status'];

            // Không cho hủy đơn thuê nếu có thiết bị đã giao mà chưa trả.
            // FOR UPDATE khóa dòng bàn giao trong suốt giao dịch để tránh cập nhật đồng thời.
            if ($new === 'cancelled' && $oldStatus !== 'cancelled') {
                $check = $conn->prepare(
                    "SELECT bg.trang_thai
                     FROM chitietdonhang ct
                     JOIN ban_giao_thue bg ON bg.ChiTietDonHang_id = ct.id
                     WHERE ct.DonHang_id = ?
                     FOR UPDATE"
                );
                $check->bind_param('i', $id);
                $check->execute();
                $handoverRows = $check->get_result()->fetch_all(MYSQLI_ASSOC);
                $check->close();
                foreach ($handoverRows as $handover) {
                    if ($handover['trang_thai'] === 'da_giao') {
                        throw new Exception('Không thể hủy đơn vì khách chưa trả thiết bị.');
                    }
                }
            }

            // Khi mở lại đơn thuê đã hủy, kiểm tra trùng lịch thuê.
            if ($oldStatus === 'cancelled' && $new !== 'cancelled') {
                $rent = $conn->prepare(
                    "SELECT ct.SanPham_id, ct.quantity, ct.start_date, ct.end_date
                     FROM chitietdonhang ct
                     JOIN sanpham s ON s.id = ct.SanPham_id
                     WHERE ct.DonHang_id = ? AND s.product_type = 'thue'"
                );
                $rent->bind_param('i', $id);
                $rent->execute();
                $rentLines = $rent->get_result()->fetch_all(MYSQLI_ASSOC);
                $rent->close();

                // Khóa các sản phẩm thuê theo thứ tự ID ổn định.
                $rentProductIds = [];
                foreach ($rentLines as $line) {
                    $rentProductIds[(int)$line['SanPham_id']] = true;
                }
                $rentProductIds = array_keys($rentProductIds);
                sort($rentProductIds, SORT_NUMERIC);
                $rentStocks = [];
                foreach ($rentProductIds as $pid) {
                    $st = $conn->prepare('SELECT stock FROM sanpham WHERE id = ? FOR UPDATE');
                    $st->bind_param('i', $pid);
                    $st->execute();
                    $sr = $st->get_result()->fetch_assoc();
                    $st->close();
                    if (!$sr) {
                        throw new Exception('Thiết bị thuê không tồn tại.');
                    }
                    $rentStocks[$pid] = (int)$sr['stock'];
                }

                foreach ($rentLines as $line) {
                    $pid = (int)$line['SanPham_id'];
                    $start = $line['start_date'];
                    $end = $line['end_date'];
                    if (!$start || !$end || $end <= $start) {
                        throw new Exception('Lịch thuê không hợp lệ.');
                    }
                    $startDate = DateTimeImmutable::createFromFormat('!Y-m-d', $start);
                    $endDate = DateTimeImmutable::createFromFormat('!Y-m-d', $end);
                    if (!$startDate || !$endDate || $startDate->format('Y-m-d') !== $start || $endDate->format('Y-m-d') !== $end) {
                        throw new Exception('Lịch thuê không hợp lệ.');
                    }
                    $book = $conn->prepare(
                        "SELECT ct.quantity, ct.start_date, ct.end_date
                         FROM chitietdonhang ct
                         JOIN donhang dh ON dh.id = ct.DonHang_id
                         WHERE ct.SanPham_id = ? AND dh.id <> ?
                           AND dh.status <> 'cancelled'
                           AND ct.start_date < ? AND ct.end_date > ?"
                    );
                    $book->bind_param('iiss', $pid, $id, $end, $start);
                    $book->execute();
                    $booked = $book->get_result()->fetch_all(MYSQLI_ASSOC);
                    $book->close();

                    for ($day = $startDate; $day < $endDate; $day = $day->modify('+1 day')) {
                        $d = $day->format('Y-m-d');
                        $used = 0;
                        foreach ($booked as $b) {
                            if ($b['start_date'] <= $d && $d < $b['end_date']) {
                                $used += (int)$b['quantity'];
                            }
                        }
                        foreach ($rentLines as $other) {
                            if ((int)$other['SanPham_id'] === $pid && $other['start_date'] <= $d && $d < $other['end_date']) {
                                $used += (int)$other['quantity'];
                            }
                        }
                        if ($used > $rentStocks[$pid]) {
                            throw new Exception('Không đủ thiết bị cho lịch thuê khi mở lại đơn.');
                        }
                    }
                }
            }

            // Sản phẩm bán đã trừ kho lúc checkout.
            // Hủy đơn -> hoàn kho; mở lại -> trừ kho.
            if (($new === 'cancelled') !== ($oldStatus === 'cancelled')) {
                $st = $conn->prepare(
                    "SELECT s.id, s.stock, ct.quantity
                     FROM chitietdonhang ct
                     INNER JOIN sanpham s ON s.id = ct.SanPham_id
                     WHERE ct.DonHang_id = ? AND s.product_type = 'mua'
                     ORDER BY s.id FOR UPDATE"
                );
                $st->bind_param('i', $id);
                $st->execute();
                $linesForStock = $st->get_result()->fetch_all(MYSQLI_ASSOC);
                $st->close();

                $qtyById = [];
                foreach ($linesForStock as $line) {
                    $pid = (int)$line['id'];
                    $qtyById[$pid] = ($qtyById[$pid] ?? 0) + (int)$line['quantity'];
                }
                ksort($qtyById, SORT_NUMERIC);
                foreach ($qtyById as $pid => $qty) {
                    if ($new === 'cancelled') {
                        $st = $conn->prepare('UPDATE sanpham SET stock = stock + ? WHERE id = ?');
                        $st->bind_param('ii', $qty, $pid);
                        $st->execute();
                        $st->close();
                    } else {
                        $st = $conn->prepare('UPDATE sanpham SET stock = stock - ? WHERE id = ? AND stock >= ?');
                        $st->bind_param('iii', $qty, $pid, $qty);
                        $st->execute();
                        $changed = $st->affected_rows;
                        $st->close();
                        if ($changed !== 1) {
                            throw new Exception('Không đủ tồn kho để mở lại đơn đã hủy.');
                        }
                    }
                }
            }

            if ($new !== $oldStatus) {
                $st = $conn->prepare('UPDATE donhang SET status = ? WHERE id = ?');
                $st->bind_param('si', $new, $id);
                $st->execute();
                $st->close();
            }
            $conn->commit();
            go('order_detail.php?id=' . $id, 'Đã cập nhật trạng thái.');
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('FILMORY admin order: ' . $e->getMessage());
            $known = [
                'Không thể hủy đơn vì khách chưa trả thiết bị.',
                'Không đủ tồn kho để mở lại đơn đã hủy.',
                'Không đủ thiết bị cho lịch thuê khi mở lại đơn.',
                'Lịch thuê không hợp lệ.',
                'Thiết bị thuê không tồn tại.'
            ];
            $error = in_array($e->getMessage(), $known, true) ? $e->getMessage() : 'Không thể cập nhật đơn hàng.';
        }
    }
}

$st = $conn->prepare('SELECT * FROM donhang WHERE id = ?');
$st->bind_param('i', $id);
$st->execute();
$order = $st->get_result()->fetch_assoc();
$st->close();
if (!$order) {
    http_response_code(404);
    exit('Không tìm thấy đơn hàng');
}

$st = $conn->prepare(
    "SELECT ct.*, s.name, s.product_type,
            COALESCE(bg.trang_thai, 'cho_nhan') AS rental_status,
            bg.ngay_giao, bg.ngay_tra, bg.ghi_chu
     FROM chitietdonhang ct
     LEFT JOIN sanpham s ON s.id = ct.SanPham_id
     LEFT JOIN ban_giao_thue bg ON bg.ChiTietDonHang_id = ct.id
     WHERE ct.DonHang_id = ? ORDER BY ct.id"
);
$st->bind_param('i', $id);
$st->execute();
$lines = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$st->close();

admin_head('Đơn hàng #' . $id, 'orders.php');
?>
<style>
.fm-order-note{background:#f8f0e5;border:1px solid #dfcdb8;padding:12px;border-radius:8px;margin:12px 0}
.fm-order-rent{display:inline-block;background:#eee1cf;color:#68442e;padding:5px 9px;border-radius:14px}
.fm-order-late{color:#aa3526;font-weight:700}
.fm-order-link{display:inline-block;margin:10px 0;color:#70452f;font-weight:700}
</style>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<div class="columns">
<section class="panel">
<h2>Thông tin khách hàng</h2>
<p><b>Họ tên:</b> <?= h($order['customer_name']) ?></p>
<p><b>Điện thoại:</b> <?= h($order['customer_phone']) ?></p>
<p><b>Địa chỉ:</b> <?= nl2br(h($order['customer_address'])) ?></p>
<p><b>Ngày:</b> <?= h($order['order_date']) ?></p>
<p><b>Tổng tiền:</b> <?= money_admin($order['total_amount']) ?></p>
</section>
<section class="panel">
<h2>Cập nhật trạng thái</h2>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
<input type="hidden" name="id" value="<?= $id ?>">
<label>Trạng thái</label>
<select name="status">
<?php foreach ($statuses as $s): ?>
<option value="<?= h($s) ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= h($statusLabels[$s]) ?></option>
<?php endforeach; ?>
</select>
<button class="btn" type="submit" onclick="return confirm('Xác nhận cập nhật đơn hàng?')">Lưu trạng thái</button>
</form>
<p class="hint">Hủy đơn bán sẽ hoàn tồn kho. Mở lại đơn sẽ kiểm tra tồn kho và lịch thuê.</p>
<div class="fm-order-note">Không thể hủy đơn thuê nếu còn thiết bị đã giao nhưng chưa được xác nhận trả.</div>
<a class="fm-order-link" href="rentals.php">→ Quản lý bàn giao / trả thiết bị</a>
</section>
</div>
<section class="panel">
<h2>Chi tiết sản phẩm</h2>
<div class="table-wrap"><table>
<thead><tr><th>Sản phẩm</th><th>Loại</th><th>SL</th><th>Đơn giá</th><th>Bắt đầu thuê</th><th>Kết thúc thuê</th><th>Bàn giao</th></tr></thead>
<tbody>
<?php foreach ($lines as $line):
    $isRent = ($line['product_type'] ?? '') === 'thue';
    $late = $isRent && $line['rental_status'] === 'da_giao' && !empty($line['end_date']) && $line['end_date'] < date('Y-m-d');
?>
<tr>
<td><?= h($line['name'] ?? 'Sản phẩm đã xóa') ?></td>
<td><?= h($isRent ? 'Cho thuê' : (($line['product_type'] ?? '') === 'mua' ? 'Mua' : '—')) ?></td>
<td><?= (int)$line['quantity'] ?></td>
<td><?= money_admin($line['price']) ?></td>
<td><?= h($line['start_date'] ?? '—') ?></td>
<td><?= h($line['end_date'] ?? '—') ?></td>
<td>
<?php if ($isRent): ?>
<span class="fm-order-rent"><?= h($rentalLabels[$line['rental_status']] ?? $line['rental_status']) ?></span>
<?php if ($late): ?><p class="fm-order-late">Quá hạn trả</p><?php endif; ?>
<?php if ($line['ngay_giao']): ?><p>Giao: <?= h($line['ngay_giao']) ?></p><?php endif; ?>
<?php if ($line['ngay_tra']): ?><p>Trả: <?= h($line['ngay_tra']) ?></p><?php endif; ?>
<?php if ($line['ghi_chu']): ?><p>Ghi chú: <?= h($line['ghi_chu']) ?></p><?php endif; ?>
<?php else: ?>—<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
</section>
<?php admin_foot(); ?>
