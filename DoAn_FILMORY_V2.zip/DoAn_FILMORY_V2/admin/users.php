<?php
require __DIR__.'/_init.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$id=positive_id($_POST['id']??0);$role=(string)($_POST['role']??'');
 if(!$id || !in_array($role,['user','admin'],true)){$error='Dữ liệu không hợp lệ.';}
 elseif($id===(int)$me['id']){$error='Không thể tự thay đổi quyền của chính mình.';}
 else{
  try{$st=$conn->prepare('UPDATE nguoidung SET role=? WHERE id=?');$st->bind_param('si',$role,$id);$st->execute();$changed=$st->affected_rows;$st->close();go('users.php','Đã cập nhật quyền tài khoản.');}catch(Throwable $e){error_log($e->getMessage());$error='Không thể cập nhật quyền.';}
 }
}
$users=$conn->query('SELECT id,username,role,created_at FROM nguoidung ORDER BY id DESC');
admin_head('Quản lý tài khoản','users.php');if($error):?><div class="error"><?=h($error)?></div><?php endif;?>
<section class="panel"><p class="hint">Tài khoản được tạo qua trang đăng ký. Quản trị viên có thể thay đổi vai trò; không hiển thị mật khẩu.</p><div class="table-wrap"><table><thead><tr><th>ID</th><th>Tên đăng nhập</th><th>Vai trò</th><th>Ngày tạo</th><th>Phân quyền</th></tr></thead><tbody><?php while($u=$users->fetch_assoc()):?><tr><td><?=$u['id']?></td><td><?=h($u['username'])?> <?=(int)$u['id']===(int)$me['id']?'(Bạn)':''?></td><td><?=h($u['role'])?></td><td><?=h($u['created_at'])?></td><td><?php if((int)$u['id']===(int)$me['id']):?>Không thể tự đổi<?php else:?><form method="post" class="inline" onsubmit="return confirm('Thay đổi quyền tài khoản này?')"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['csrf_token'])?>"><input type="hidden" name="id" value="<?=$u['id']?>"><select name="role"><option value="user" <?=$u['role']==='user'?'selected':''?>>user</option><option value="admin" <?=$u['role']==='admin'?'selected':''?>>admin</option></select><button class="small-btn">Lưu</button></form><?php endif;?></td></tr><?php endwhile;?></tbody></table></div></section><?php admin_foot();?>
