<?php
require __DIR__.'/_init.php';
$id=positive_id($_GET['id']??($_POST['id']??0));$row=['name'=>'','description'=>''];
if($id){$st=$conn->prepare('SELECT name,description FROM danhmucsanpham WHERE id=?');$st->bind_param('i',$id);$st->execute();$data=$st->get_result()->fetch_assoc();$st->close();if(!$data){http_response_code(404);exit('Không tìm thấy danh mục');}$row=$data;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$row['name']=trim((string)($_POST['name']??''));$row['description']=trim((string)($_POST['description']??''));
 if($row['name']===''||mb_strlen($row['name'])>100||mb_strlen($row['description'])>3000){$error='Tên hoặc mô tả không hợp lệ.';}
 else{try{$name=$row['name'];$desc=$row['description'];if($id){$st=$conn->prepare('UPDATE danhmucsanpham SET name=?,description=? WHERE id=?');$st->bind_param('ssi',$name,$desc,$id);}else{$st=$conn->prepare('INSERT INTO danhmucsanpham(name,description) VALUES(?,?)');$st->bind_param('ss',$name,$desc);}$st->execute();$st->close();go('categories.php','Đã lưu danh mục.');}catch(Throwable $e){error_log($e->getMessage());$error='Không thể lưu danh mục.';}}
}
admin_head($id?'Sửa danh mục':'Thêm danh mục','categories.php');if($error):?><div class="error"><?=h($error)?></div><?php endif;?><section class="panel form-panel"><form method="post"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['csrf_token'])?>"><input type="hidden" name="id" value="<?=$id?>"><label>Tên danh mục *</label><input name="name" maxlength="100" required value="<?=h($row['name'])?>"><label>Mô tả</label><textarea name="description" rows="5"><?=h($row['description'])?></textarea><div class="actions"><button class="btn">Lưu danh mục</button><a href="categories.php">Hủy</a></div></form></section><?php admin_foot();?>
