<?php
require __DIR__.'/_init.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$id=positive_id($_POST['id']??0);
 if(!$id){$error='Danh mục không hợp lệ.';}else{
  $st=$conn->prepare('SELECT COUNT(*) AS n FROM sanpham WHERE DanhMucSanPham_id=?');$st->bind_param('i',$id);$st->execute();$n=(int)$st->get_result()->fetch_assoc()['n'];$st->close();
  if($n){$error='Danh mục đang có sản phẩm, không thể xóa.';}else{
   try{$st=$conn->prepare('DELETE FROM danhmucsanpham WHERE id=?');$st->bind_param('i',$id);$st->execute();$st->close();go('categories.php','Đã xóa danh mục.');}catch(Throwable $e){error_log($e->getMessage());$error='Không thể xóa danh mục.';}
  }
 }
}
$result=$conn->query('SELECT d.id,d.name,d.description,COUNT(s.id) AS n FROM danhmucsanpham d LEFT JOIN sanpham s ON s.DanhMucSanPham_id=d.id GROUP BY d.id,d.name,d.description ORDER BY d.id DESC');
admin_head('Quản lý danh mục','categories.php');?><div class="actions"><a class="btn" href="category_form.php">+ Thêm danh mục</a></div>
<?php if($error):?><div class="error"><?=h($error)?></div><?php endif;?>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Tên danh mục</th><th>Mô tả</th><th>Số sản phẩm</th><th>Thao tác</th></tr></thead><tbody>
<?php while($d=$result->fetch_assoc()):?><tr><td><?=$d['id']?></td><td><strong><?=h($d['name'])?></strong></td><td><?=h($d['description'])?></td><td><?=$d['n']?></td><td><div class="inline"><a href="category_form.php?id=<?=$d['id']?>">Sửa</a><form method="post" onsubmit="return confirm('Xóa danh mục?')"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['csrf_token'])?>"><input type="hidden" name="id" value="<?=$d['id']?>"><button class="danger-link">Xóa</button></form></div></td></tr><?php endwhile;?></tbody></table></div></section><?php admin_foot();?>
