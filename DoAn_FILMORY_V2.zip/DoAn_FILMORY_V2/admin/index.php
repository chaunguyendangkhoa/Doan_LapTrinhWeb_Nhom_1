<?php
require __DIR__.'/_init.php';
$products=(int)$conn->query('SELECT COUNT(*) FROM sanpham')->fetch_row()[0];
$categories=(int)$conn->query('SELECT COUNT(*) FROM danhmucsanpham')->fetch_row()[0];
$orders=(int)$conn->query('SELECT COUNT(*) FROM donhang')->fetch_row()[0];
$users=(int)$conn->query('SELECT COUNT(*) FROM nguoidung')->fetch_row()[0];
$pending=(int)$conn->query("SELECT COUNT(*) FROM donhang WHERE status='pending'")->fetch_row()[0];
$recent=$conn->query('SELECT id,customer_name,total_amount,status,order_date FROM donhang ORDER BY id DESC LIMIT 8');
admin_head('Tổng quan','index.php'); ?>
<div class="stats"><div><span>Sản phẩm</span><strong><?=$products?></strong></div><div><span>Danh mục</span><strong><?=$categories?></strong></div><div><span>Đơn hàng</span><strong><?=$orders?></strong></div><div><span>Tài khoản</span><strong><?=$users?></strong></div></div>
<section class="panel"><h2>Đơn hàng mới <small>(<?=$pending?> đang chờ)</small></h2><div class="table-wrap"><table><thead><tr><th>Mã</th><th>Khách hàng</th><th>Tổng tiền</th><th>Trạng thái</th><th>Ngày</th><th></th></tr></thead><tbody>
<?php while($o=$recent->fetch_assoc()): ?><tr><td>#<?=h($o['id'])?></td><td><?=h($o['customer_name'])?></td><td><?=money_admin($o['total_amount'])?></td><td><?=h($o['status'])?></td><td><?=h($o['order_date'])?></td><td><a href="order_detail.php?id=<?=$o['id']?>">Xem</a></td></tr><?php endwhile; ?>
</tbody></table></div></section><?php admin_foot(); ?>
