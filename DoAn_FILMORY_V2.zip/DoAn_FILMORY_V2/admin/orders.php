<?php
require __DIR__ . '/_init.php';
$allowed = ['all', 'pending', 'processing', 'completed', 'cancelled'];
$filter = (string)($_GET['status'] ?? 'all');
if (!in_array($filter, $allowed, true)) $filter = 'all';
$types = ['all', 'mua', 'thue', 'mixed'];
$type = (string)($_GET['type'] ?? 'all');
if (!in_array($type, $types, true)) $type = 'all';

// Lấy loại đơn từ chi tiết sản phẩm. Đơn có cả mua và thuê được gọi là hỗn hợp.
$sql = "SELECT dh.*,
  COALESCE(t.so_mua, 0) AS so_mua,
  COALESCE(t.so_thue, 0) AS so_thue,
  COALESCE(t.so_mon, 0) AS so_mon,
  COALESCE(t.so_da_giao, 0) AS so_da_giao,
  COALESCE(t.so_da_tra, 0) AS so_da_tra,
  COALESCE(t.so_qua_han, 0) AS so_qua_han
FROM donhang dh
LEFT JOIN (
  SELECT ct.DonHang_id,
    SUM(CASE WHEN sp.product_type = 'mua' THEN 1 ELSE 0 END) AS so_mua,
    SUM(CASE WHEN sp.product_type = 'thue' THEN 1 ELSE 0 END) AS so_thue,
    COUNT(*) AS so_mon,
    SUM(CASE WHEN sp.product_type = 'thue' AND bg.trang_thai = 'da_giao' THEN 1 ELSE 0 END) AS so_da_giao,
    SUM(CASE WHEN sp.product_type = 'thue' AND bg.trang_thai = 'da_tra' THEN 1 ELSE 0 END) AS so_da_tra,
    SUM(CASE WHEN sp.product_type = 'thue' AND bg.trang_thai = 'da_giao' AND ct.end_date < CURDATE() THEN 1 ELSE 0 END) AS so_qua_han
  FROM chitietdonhang ct
  LEFT JOIN sanpham sp ON sp.id = ct.SanPham_id
  LEFT JOIN ban_giao_thue bg ON bg.ChiTietDonHang_id = ct.id
  GROUP BY ct.DonHang_id
) t ON t.DonHang_id = dh.id
WHERE (? = 'all' OR dh.status = ?)
  AND (? = 'all'
    OR (? = 'mua' AND COALESCE(t.so_mua,0) > 0 AND COALESCE(t.so_thue,0) = 0)
    OR (? = 'thue' AND COALESCE(t.so_thue,0) > 0 AND COALESCE(t.so_mua,0) = 0)
    OR (? = 'mixed' AND COALESCE(t.so_mua,0) > 0 AND COALESCE(t.so_thue,0) > 0))
ORDER BY dh.id DESC";
$st = $conn->prepare($sql);
$st->bind_param('ssssss', $filter, $filter, $type, $type, $type, $type);
$st->execute();
$result = $st->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
$st->close();

$counts = ['pending'=>0,'processing'=>0,'completed'=>0,'cancelled'=>0];
$countResult = $conn->query('SELECT status, COUNT(*) AS n FROM donhang GROUP BY status');
while ($c = $countResult->fetch_assoc()) {
    if (isset($counts[$c['status']])) $counts[$c['status']] = (int)$c['n'];
}
$statusNames = ['pending'=>'Chờ xác nhận', 'processing'=>'Đang xử lý', 'completed'=>'Hoàn thành', 'cancelled'=>'Đã hủy'];
$typeNames = ['all'=>'Tất cả loại', 'mua'=>'Chỉ mua', 'thue'=>'Chỉ thuê', 'mixed'=>'Mua và thuê'];
admin_head('Quản lý đơn hàng', 'orders.php');
?>
<style>
.order-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0}
.order-stat{background:#fffaf3;border:1px solid #e3d2bc;border-radius:12px;padding:17px}
.order-stat strong{display:block;font-size:25px;color:#70452f;margin-top:6px}
.order-stat span{font-size:13px;color:#806854}
.order-filter-form{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:14px 0}
.order-filter-form select{padding:10px;border:1px solid #d6c2a8;border-radius:7px;background:#fffaf3;color:#563a28}
.order-filter-form button,.order-link{background:#70452f;color:white;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;cursor:pointer;display:inline-block}
.order-kind{display:inline-block;background:#eee0ca;color:#69452d;padding:5px 10px;border-radius:20px;font-size:12px}
.order-muted{color:#8a7665;font-size:12px}
.order-alert{color:#a43726;font-weight:700}
@media(max-width:800px){.order-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
<div class="order-stats">
<?php foreach ($counts as $key=>$n): ?>
<div class="order-stat"><span><?=h($statusNames[$key])?></span><strong><?= $n ?></strong></div>
<?php endforeach; ?>
</div>
<form class="order-filter-form" method="get">
<label>Trạng thái
<select name="status">
<option value="all" <?= $filter==='all'?'selected':'' ?>>Tất cả trạng thái</option>
<?php foreach ($statusNames as $key=>$name): ?><option value="<?=h($key)?>" <?= $filter===$key?'selected':'' ?>><?=h($name)?></option><?php endforeach; ?>
</select></label>
<label>Loại đơn
<select name="type">
<?php foreach ($typeNames as $key=>$name): ?><option value="<?=h($key)?>" <?= $type===$key?'selected':'' ?>><?=h($name)?></option><?php endforeach; ?>
</select></label>
<button type="submit">Lọc đơn hàng</button>
<a class="order-link" href="rentals.php">Quản lý bàn giao</a>
</form>
<section class="panel"><div class="table-wrap"><table>
<thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Điện thoại</th><th>Loại đơn</th><th>Tổng tiền</th><th>Trạng thái</th><th>Ngày đặt</th><th>Thao tác</th></tr></thead>
<tbody>
<?php foreach ($orders as $o):
    $buy=(int)$o['so_mua']; $rent=(int)$o['so_thue'];
    $kind=$buy && $rent?'Mua + thuê':($rent?'Cho thuê':($buy?'Mua hàng':'Chưa rõ'));
?>
<tr>
<td>#<?= (int)$o['id'] ?></td>
<td><?=h($o['customer_name'])?></td>
<td><?=h($o['customer_phone'])?></td>
<td><span class="order-kind"><?=h($kind)?></span>
<?php if ($rent): ?><div class="order-muted">Thuê: <?=$rent?> dòng sản phẩm</div>
<?php if ((int)$o['so_qua_han']>0): ?><div class="order-alert">⚠ <?= (int)$o['so_qua_han'] ?> mục quá hạn</div><?php endif; ?>
<?php if ((int)$o['so_da_giao']>0 || (int)$o['so_da_tra']>0): ?><div class="order-muted">Đã giao: <?= (int)$o['so_da_giao'] ?> · Đã trả: <?= (int)$o['so_da_tra'] ?></div><?php endif; ?>
<?php endif; ?></td>
<td><?=money_admin($o['total_amount'])?></td>
<td><span class="pill"><?=h($statusNames[$o['status']] ?? $o['status'])?></span></td>
<td><?=h($o['order_date'])?></td>
<td><a href="order_detail.php?id=<?=(int)$o['id']?>">Chi tiết</a></td>
</tr>
<?php endforeach; ?>
<?php if (!$orders): ?><tr><td colspan="8">Không có đơn hàng phù hợp với bộ lọc.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php admin_foot(); ?>
