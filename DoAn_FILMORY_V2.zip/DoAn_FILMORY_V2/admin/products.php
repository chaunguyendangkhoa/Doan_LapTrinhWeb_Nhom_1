<?php
require __DIR__.'/_init.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check(); $id=positive_id($_POST['id']??0);
 if(!$id){$error='ID không hợp lệ.';}else{
  $st=$conn->prepare('SELECT COUNT(*) AS n FROM chitietdonhang WHERE SanPham_id=?');$st->bind_param('i',$id);$st->execute();$n=(int)$st->get_result()->fetch_assoc()['n'];$st->close();
  if($n>0){$error='Sản phẩm đã có trong đơn hàng, không thể xóa. Hãy chỉnh tồn kho về 0.';}
  else {try{$st=$conn->prepare('DELETE FROM sanpham WHERE id=?');$st->bind_param('i',$id);$st->execute();$st->close();go('products.php','Đã xóa sản phẩm.');}catch(Throwable $e){error_log($e->getMessage());$error='Không thể xóa sản phẩm.';}}
 }
}
$q=trim((string)($_GET['q']??''));$like='%'.$q.'%';
$st=$conn->prepare('SELECT s.*,d.name AS category_name FROM sanpham s LEFT JOIN danhmucsanpham d ON d.id=s.DanhMucSanPham_id WHERE s.name LIKE ? ORDER BY s.id DESC');$st->bind_param('s',$like);$st->execute();$result=$st->get_result();
admin_head('Quản lý sản phẩm','products.php'); ?>
<div class="actions"><form method="get" class="search"><input name="q" value="<?=h($q)?>" placeholder="Tìm sản phẩm..."><button>Tìm</button></form><a class="btn" href="product_form.php">+ Thêm sản phẩm</a></div>
<?php if($error):?><div class="error"><?=h($error)?></div><?php endif;?>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Sản phẩm</th><th>Danh mục</th><th>Loại</th><th>Giá</th><th>Tồn kho</th><th>Thao tác</th></tr></thead><tbody>
<?php while($s=$result->fetch_assoc()):?><tr><td><?=$s['id']?></td><td><strong><?=h($s['name'])?></strong></td><td><?=h($s['category_name']??'Chưa có')?></td><td><?=h($s['product_type'])?></td><td><?=money_admin($s['price'])?></td><td><?=h($s['stock'])?></td><td><div class="inline"><a href="product_form.php?id=<?=$s['id']?>">Sửa</a><form method="post" onsubmit="return confirm('Xóa sản phẩm này?')"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['csrf_token'])?>"><input type="hidden" name="id" value="<?=$s['id']?>"><button class="danger-link">Xóa</button></form></div></td></tr><?php endwhile;?></tbody></table></div></section><?php $st->close();admin_foot(); ?>
