
<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

// Kiểm tra đăng nhập
if (!auth_logged_in()) {
    header('Location: ../login.php');
    exit;
}

// Kiểm tra quyền Admin từ database
$authId = (int)$_SESSION['user_id'];

$st = $conn->prepare(
    'SELECT id, username, role
     FROM nguoidung
     WHERE id = ?
     LIMIT 1'
);

$st->bind_param('i', $authId);
$st->execute();
$me = $st->get_result()->fetch_assoc();
$st->close();

if (!$me || $me['role'] !== 'admin') {
    http_response_code(403);
    exit('403 - Chỉ quản trị viên được truy cập.');
}

$_SESSION['role'] = 'admin';
$_SESSION['username'] = $me['username'];

// Chống XSS
function h($v) {
    return htmlspecialchars(
        (string)$v,
        ENT_QUOTES,
        'UTF-8'
    );
}

// Định dạng tiền
function money_admin($v) {
    return number_format(
        (float)$v,
        0,
        ',',
        '.'
    ) . 'đ';
}

// Chỉ cho phép POST
function post_only() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Yêu cầu không hợp lệ');
    }
}

// Kiểm tra CSRF
function csrf_check() {
    if (!auth_csrf_valid()) {
        http_response_code(403);
        exit('Biểu mẫu hết hạn. Hãy tải lại trang.');
    }
}

// Chuyển trang
function go($page, $msg = '') {
    $url = $page;

    if ($msg !== '') {
        $url .= (
            str_contains($page, '?') ? '&' : '?'
        ) . 'msg=' . rawurlencode($msg);
    }

    header('Location: ' . $url);
    exit;
}

// Kiểm tra ID
function positive_id($value) {
    $v = filter_var(
        $value,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    );

    return $v === false ? 0 : $v;
}

// Giao diện đầu trang Admin
function admin_head($title, $tab = '') {
    global $me;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>
        <?= h($title) ?> | FILMORY Admin
    </title>

    <!-- CSS giao diện Admin -->
    <link rel="stylesheet"
          href="assets/admin.css?v=1">

    <!-- CSS sửa font tiếng Việt -->
    <link rel="stylesheet"
          href="../assets/css/font-fix.css?v=2">

</head>

<body>

<div class="admin-layout">

    <aside class="sidebar">

        <a class="brand" href="index.php">
            FILMORY<span>.</span>
            <small>QUẢN TRỊ VIỆT CỔ</small>
        </a>

        <nav>
            <?php
            $menu = [
                'index.php' => 'Tổng quan',
                'products.php' => 'Sản phẩm',
                'categories.php' => 'Danh mục',
                'orders.php' => 'Đơn hàng',
                'rentals.php' => 'Quản lý thuê',
                'users.php' => 'Tài khoản'
            ];

            foreach ($menu as $href => $name):
            ?>
                <a
                    class="<?= $tab === $href ? 'selected' : '' ?>"
                    href="<?= h($href) ?>"
                >
                    <?= h($name) ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <a class="back" href="../index.php">
            ← Về cửa hàng
        </a>

    </aside>

    <main class="main">

        <div class="top">

            <div>
                <p class="eyebrow">
                    FILMORY / QUẢN TRỊ
                </p>

                <h1><?= h($title) ?></h1>
            </div>

            <div class="user">
                Xin chào,
                <strong>
                    <?= h($me['username']) ?>
                </strong>
            </div>

        </div>

        <?php if (isset($_GET['msg'])): ?>
            <div class="notice">
                <?= h($_GET['msg']) ?>
            </div>
        <?php endif; ?>

<?php
}

// Giao diện cuối trang Admin
function admin_foot() {
    echo '</main></div></body></html>';
}
?>
