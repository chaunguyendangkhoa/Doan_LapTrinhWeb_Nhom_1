<?php
require __DIR__ . '/_init.php';
// _init.php của Admin phải kiểm tra đăng nhập và quyền admin.
$error = '';
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $detailId = positive_id($_POST['detail_id'] ?? 0);
    $action = (string)($_POST['action'] ?? '');
    $note = trim((string)($_POST['note'] ?? ''));
    if (!$detailId || !in_array($action, ['handover','return'], true)) {
        $error = 'Dữ liệu không hợp lệ.';
    } elseif (mb_strlen($note, 'UTF-8') > 500) {
        $error = 'Ghi chú tối đa 500 ký tự.';
    } else {
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare(
                "SELECT ct.id, dh.status, ct.start_date, ct.end_date
                 FROM chitietdonhang ct
                 JOIN donhang dh ON dh.id = ct.DonHang_id
                 JOIN sanpham sp ON sp.id = ct.SanPham_id
                 WHERE ct.id = ? AND sp.product_type = 'thue'
                 FOR UPDATE"
            );
            $stmt->bind_param('i', $detailId);
            $stmt->execute();
            $r = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if (!$r) {
                throw new RuntimeException('Không tìm thấy chi tiết thuê.');
            }
            if ($r['status'] === 'cancelled') {
                throw new RuntimeException('Không thể bàn giao đơn đã hủy.');
            }
            $stmt = $conn->prepare(
                "INSERT IGNORE INTO ban_giao_thue (ChiTietDonHang_id) VALUES (?)"
            );
            $stmt->bind_param('i', $detailId);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare(
                "SELECT trang_thai FROM ban_giao_thue WHERE ChiTietDonHang_id = ? FOR UPDATE"
            );
            $stmt->bind_param('i', $detailId);
            $stmt->execute();
            $state = $stmt->get_result()->fetch_assoc()['trang_thai'];
            $stmt->close();
            if ($action === 'handover' && $state === 'cho_nhan') {
                $stmt = $conn->prepare(
                    "UPDATE ban_giao_thue SET trang_thai='da_giao', ngay_giao=NOW(), ghi_chu=?
                     WHERE ChiTietDonHang_id=?"
                );
            } elseif ($action === 'return' && $state === 'da_giao') {
                $stmt = $conn->prepare(
                    "UPDATE ban_giao_thue SET trang_thai='da_tra', ngay_tra=NOW(), ghi_chu=?
                     WHERE ChiTietDonHang_id=?"
                );
            } else {
                throw new RuntimeException('Trạng thái hiện tại không cho phép thao tác này.');
            }
            $stmt->bind_param('si', $note, $detailId);
            $stmt->execute();
            $stmt->close();
            $conn->commit();
            header('Location: rentals.php?done=1');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            error_log($ex->getMessage());
            $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'Không thể cập nhật bàn giao. Hãy kiểm tra database.';
        }
    }
}
if (isset($_GET['done'])) $notice = 'Đã cập nhật trạng thái thành công.';
$sql = "SELECT ct.id AS detail_id, dh.id AS order_id, dh.customer_name,
 dh.customer_phone, dh.status AS order_status,
 sp.name AS product_name, ct.quantity, ct.start_date, ct.end_date,
 COALESCE(bg.trang_thai, 'cho_nhan') AS rental_status,
 bg.ngay_giao, bg.ngay_tra, bg.ghi_chu
 FROM chitietdonhang ct
 JOIN sanpham sp ON sp.id=ct.SanPham_id AND sp.product_type='thue'
 JOIN donhang dh ON dh.id=ct.DonHang_id
 LEFT JOIN ban_giao_thue bg ON bg.ChiTietDonHang_id=ct.id
 ORDER BY (CASE WHEN COALESCE(bg.trang_thai,'cho_nhan')='da_giao'
 AND ct.end_date < CURDATE() THEN 0 ELSE 1 END), dh.id DESC, ct.id DESC";
$rows = $conn->query($sql);
admin_head('Quản lý bàn giao & trả thiết bị', 'rentals.php');
?>
<style>
.rental-tools{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}
.rental-tools input{padding:10px;border:1px solid #c9b49b;border-radius:7px;max-width:320px}
.rental-tag{display:inline-block;padding:5px 9px;border-radius:15px;background:#eee0cd;color:#5a3826}
.rental-late{background:#ffe0d8;color:#9e3021}
.rental-form{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.rental-form input{padding:7px;max-width:160px;border:1px solid #d5c2aa;border-radius:6px}
.rental-form button{background:#70452f;color:white;border:0;border-radius:6px;padding:8px 12px;cursor:pointer}
.rental-table td{vertical-align:top}
.rental-message{padding:12px;margin:12px 0;border-radius:8px;background:#f7eadb}
</style>
<p>Quản lý từng sản phẩm thuê trong đơn hàng. Không thay đổi trạng thái thanh toán hoặc tồn kho sản phẩm bán.</p>
<?php if ($error): ?><div class="error"><?= h($error) ?></div><?php endif; ?>
<?php if ($notice): ?><div class="rental-message"><?= h($notice) ?></div><?php endif; ?>
<div class="rental-tools"><input id="rentalSearch" placeholder="Tìm mã đơn, tên khách, thiết bị..." oninput="filterRentals()"></div>
<section class="panel"><div class="table-wrap"><table class="rental-table">
<thead><tr><th>Đơn / khách</th><th>Thiết bị</th><th>Lịch thuê</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
<tbody>
<?php $count=0; while ($row=$rows->fetch_assoc()): $count++;
$late = $row['rental_status']==='da_giao' && $row['end_date'] < date('Y-m-d');
$stateLabels=['cho_nhan'=>'Chờ nhận','da_giao'=>'Đã giao','da_tra'=>'Đã trả'];
?>
<tr class="rental-row">
<td><strong>#<?= (int)$row['order_id'] ?></strong><p><?= h($row['customer_name']) ?></p><small><?= h($row['customer_phone']) ?></small><p>Đơn: <?= h($row['order_status']) ?></p></td>
<td><strong><?= h($row['product_name']) ?></strong><p>SL: <?= (int)$row['quantity'] ?></p></td>
<td><?= h($row['start_date']) ?> → <?= h($row['end_date']) ?></td>
<td><span class="rental-tag <?= $late?'rental-late':'' ?>"><?= $late ? 'Quá hạn trả' : h($stateLabels[$row['rental_status']] ?? $row['rental_status']) ?></span>
<?php if ($row['ngay_giao']): ?><p>Giao: <?= h($row['ngay_giao']) ?></p><?php endif; ?>
<?php if ($row['ngay_tra']): ?><p>Trả: <?= h($row['ngay_tra']) ?></p><?php endif; ?>
<?php if ($row['ghi_chu']): ?><p><?= h($row['ghi_chu']) ?></p><?php endif; ?>
</td>
<td>
<?php if ($row['order_status'] !== 'cancelled' && in_array($row['rental_status'],['cho_nhan','da_giao'],true)): ?>
<form class="rental-form" method="post" onsubmit="return confirm('Xác nhận thao tác bàn giao / trả thiết bị?')">
<input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
<input type="hidden" name="detail_id" value="<?= (int)$row['detail_id'] ?>">
<input type="hidden" name="action" value="<?= $row['rental_status']==='cho_nhan'?'handover':'return' ?>">
<input name="note" maxlength="500" placeholder="Tình trạng / ghi chú">
<button type="submit"><?= $row['rental_status']==='cho_nhan'?'Xác nhận giao':'Xác nhận trả' ?></button>
</form>
<?php else: ?>—<?php endif; ?>
</td></tr>
<?php endwhile; ?>
<?php if (!$count): ?><tr><td colspan="5">Chưa có đơn thuê nào.</td></tr><?php endif; ?>
</tbody></table></div></section>
<script>
function filterRentals(){
 const q=document.getElementById('rentalSearch').value.toLocaleLowerCase('vi');
 document.querySelectorAll('.rental-row').forEach(row=>{
   row.style.display=row.textContent.toLocaleLowerCase('vi').includes(q)?'':'none';
 });
}
</script>
<?php admin_foot(); ?>
