<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
if (auth_logged_in()) {
    header('Location: index.php');
    exit;
}
$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if (!auth_csrf_valid()) {
        $error = 'Phiên biểu mẫu không hợp lệ. Vui lòng tải lại trang.';
    } elseif ($username === '' || $password === '') {
        $error = 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.';
    } else {
        $stmt = $conn->prepare('SELECT id, username, password, role FROM nguoidung WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit;
        }
        $error = 'Tên đăng nhập hoặc mật khẩu không đúng.';
    }
}
include __DIR__ . '/header.php';
?>
<link rel="stylesheet" href="assets/css/auth.css?v=1">
<main class="auth-page"><section class="auth-card">
<p class="auth-eyebrow">FILMORY • TÀI KHOẢN</p><h1>Đăng nhập</h1>
<p class="auth-subtitle">Chào mừng bạn trở lại với FILMORY.</p>
<?php if ($error !== ''): ?><div class="auth-error" role="alert"><?= auth_e($error) ?></div><?php endif; ?>
<?php if (isset($_GET['registered'])): ?><div class="auth-success">Đăng ký thành công! Hãy đăng nhập.</div><?php endif; ?>
<form method="post" action="login.php">
<input type="hidden" name="csrf_token" value="<?= auth_e($_SESSION['csrf_token']) ?>">
<label for="username">Tên đăng nhập</label><input id="username" name="username" maxlength="50" required autocomplete="username" value="<?= auth_e($username) ?>">
<label for="password">Mật khẩu</label><input id="password" name="password" type="password" required autocomplete="current-password">
<button type="submit">Đăng nhập</button>
</form><p class="auth-bottom">Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a></p>
</section></main>
<?php include __DIR__ . '/footer.php'; ?>
