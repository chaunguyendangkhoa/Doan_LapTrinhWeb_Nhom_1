
<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "doan";
$port = 3307;

$conn = new mysqli(
    $servername,
    $username,
    $password,
    $dbname,
    $port
);

if ($conn->connect_error) {
    die("Loi ket noi database: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
