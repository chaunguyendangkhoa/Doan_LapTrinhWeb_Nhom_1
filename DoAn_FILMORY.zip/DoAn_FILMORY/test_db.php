
<?php
require_once "config/database.php";

echo "<h2>KIEM TRA DATABASE FILMORY</h2>";

// Kiem tra ket noi
if ($conn->connect_error) {
    die("Ket noi that bai: " . $conn->connect_error);
}

echo "<p style='color:green'>1. Ket noi MySQL thanh cong!</p>";

// Kiem tra database dang su dung
$result = $conn->query("SELECT DATABASE() AS ten_database");
$row = $result->fetch_assoc();

echo "2. Database dang dung: " . $row["ten_database"] . "<br>";

// Dem san pham
$result = $conn->query("SELECT COUNT(*) AS tong FROM sanpham");

if ($result) {
    $row = $result->fetch_assoc();
    echo "3. Tong so san pham: " . $row["tong"] . "<br>";
} else {
    echo "Loi truy van san pham: " . $conn->error;
}

// Hien thi danh sach san pham
$result = $conn->query(
    "SELECT id, name, price, product_type FROM sanpham"
);

if ($result) {
    echo "<h3>Danh sach san pham</h3>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>Ten san pham</th><th>Gia</th><th>Loai</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
        echo "<td>" . number_format($row["price"]) . " VND</td>";
        echo "<td>" . $row["product_type"] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
}

$conn->close();
?>
