
<?php
require_once "config/database.php";

// Lay loai san pham dang duoc chon
$type = $_GET["type"] ?? "all";

if (!in_array($type, ["all", "thue", "mua"])) {
    $type = "all";
}

// Lay danh sach danh muc
$sqlCategory = "SELECT * FROM DanhMucSanPham ORDER BY id ASC";
$categories = $conn->query($sqlCategory);

// Lay san pham va ten danh muc
$sql = "SELECT SanPham.*, DanhMucSanPham.name AS category_name
        FROM SanPham
        LEFT JOIN DanhMucSanPham
        ON SanPham.DanhMucSanPham_id = DanhMucSanPham.id";

if ($type == "thue" || $type == "mua") {
    $sql .= " WHERE SanPham.product_type = ?";
}

$sql .= " ORDER BY SanPham.id DESC";

$stmt = $conn->prepare($sql);

if ($type == "thue" || $type == "mua") {
    $stmt->bind_param("s", $type);
}

$stmt->execute();
$products = $stmt->get_result();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

function money($price) {
    return number_format((float)$price, 0, ",", ".") . "đ";
}
?>

<?php include "header.php"; ?>

<main class="products-page">
    <section class="products-heading">
        <p class="eyebrow">FILMORY CAMERA STORE</p>
        <h1>Thiết bị dành cho người yêu nhiếp ảnh</h1>
        <p>
            Khám phá máy ảnh, ống kính và phụ kiện
            phục vụ mọi hành trình sáng tạo.
        </p>
    </section>

    <section class="products-container">
        <div class="products-toolbar">
            <div>
                <h2>Sản phẩm của chúng tôi</h2>
                <p>
                    <?php echo $products->num_rows; ?> sản phẩm
                </p>
            </div>

            <div class="product-filters">
                <a href="products.php"
                   class="<?php echo $type == 'all' ? 'active' : ''; ?>">
                    Tất cả
                </a>

                <a href="products.php?type=thue"
                   class="<?php echo $type == 'thue' ? 'active' : ''; ?>">
                    Cho thuê
                </a>

                <a href="products.php?type=mua"
                   class="<?php echo $type == 'mua' ? 'active' : ''; ?>">
                    Mua sản phẩm
                </a>
            </div>
        </div>

        <div class="product-grid">
            <?php if ($products->num_rows > 0): ?>

                <?php while ($product = $products->fetch_assoc()): ?>

                    <article class="product-card">
                        <div class="product-image">
                            <?php if (!empty($product["image"])): ?>
                                <img
                                    src="assets/images/<?php echo e($product['image']); ?>"
                                    alt="<?php echo e($product['name']); ?>"
                                    onerror="this.style.display='none';"
                                >
                            <?php else: ?>
                                <div class="no-image">
                                    FILMORY
                                </div>
                            <?php endif; ?>

                            <span class="product-badge">
                                <?php
                                echo $product["product_type"] == "thue"
                                    ? "Cho thuê"
                                    : "Bán";
                                ?>
                            </span>
                        </div>

                        <div class="product-info">
                            <p class="product-category">
                                <?php
                                echo e($product["category_name"] ?? "Chưa phân loại");
                                ?>
                            </p>

                            <h3><?php echo e($product["name"]); ?></h3>

                            <p class="product-description">
                                <?php echo e($product["description"]); ?>
                            </p>

                            <div class="product-bottom">
                                <div class="product-price">
                                    <strong>
                                        <?php echo money($product["price"]); ?>
                                    </strong>

                                    <?php if ($product["product_type"] == "thue"): ?>
                                        <span>/ ngày</span>
                                    <?php endif; ?>
                                </div>

                                <span class="product-stock">
                                    <?php
                                    echo (int)$product["stock"] > 0
                                        ? "Còn hàng"
                                        : "Hết hàng";
                                    ?>
                                </span>
                            </div>

                            <?php if ((int)$product["stock"] > 0): ?>
                                <a
                                    class="product-button"
                                    href="product_detail.php?id=<?php echo (int)$product['id']; ?>"
                                >
                                    Xem chi tiết
                                </a>
                            <?php else: ?>
                                <button class="product-button" disabled>
                                    Tạm hết hàng
                                </button>
                            <?php endif; ?>
                        </div>
                    </article>

                <?php endwhile; ?>

            <?php else: ?>
                <p>Chưa có sản phẩm phù hợp.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
$stmt->close();
include "footer.php";
?>
